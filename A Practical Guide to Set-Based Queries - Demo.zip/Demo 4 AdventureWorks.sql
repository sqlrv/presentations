--
-- Creating an Inlineable Scalar Function
--
CREATE FUNCTION [dbo].[ufnLeadingZeros](
    @Value int
) 
RETURNS varchar(8) 
WITH SCHEMABINDING 
AS 
BEGIN
    DECLARE @ReturnValue varchar(8);

    SET @ReturnValue = CONVERT(varchar(8), @Value);
    SET @ReturnValue = REPLICATE('0', 8 - DATALENGTH(@ReturnValue)) + @ReturnValue;

    RETURN (@ReturnValue);
END;
GO

--
-- Retooled:
--
CREATE FUNCTION dbo.ufnLeadingZeros(@Value int)
RETURNS varchar(8)
WITH SCHEMABINDING 
AS BEGIN
	RETURN (RIGHT(REPEAT('0',8) + CAST(@Value AS varchar(8)),8));
END

--
-- Reducing conditional branching for inlineable capabilities
--
CREATE FUNCTION [dbo].[ufnGetContactInformation](@PersonID int)
RETURNS @retContactInformation TABLE 
(
    -- Columns returned by the function
    [PersonID] int NOT NULL, 
    [FirstName] [nvarchar](50) NULL, 
    [LastName] [nvarchar](50) NULL, 
	[JobTitle] [nvarchar](50) NULL,
    [BusinessEntityType] [nvarchar](50) NULL
)
AS 
-- Returns the first name, last name, job title and business entity type for the specified contact.
-- Since a contact can serve multiple roles, more than one row may be returned.
BEGIN
	IF @PersonID IS NOT NULL 
		BEGIN
		IF EXISTS(SELECT * FROM [HumanResources].[Employee] e 
					WHERE e.[BusinessEntityID] = @PersonID) 
			INSERT INTO @retContactInformation
				SELECT @PersonID, p.FirstName, p.LastName, e.[JobTitle], 'Employee'
				FROM [HumanResources].[Employee] AS e
					INNER JOIN [Person].[Person] p
					ON p.[BusinessEntityID] = e.[BusinessEntityID]
				WHERE e.[BusinessEntityID] = @PersonID;

		IF EXISTS(SELECT * FROM [Purchasing].[Vendor] AS v
					INNER JOIN [Person].[BusinessEntityContact] bec 
					ON bec.[BusinessEntityID] = v.[BusinessEntityID]
					WHERE bec.[PersonID] = @PersonID)
			INSERT INTO @retContactInformation
				SELECT @PersonID, p.FirstName, p.LastName, ct.[Name], 'Vendor Contact' 
				FROM [Purchasing].[Vendor] AS v
					INNER JOIN [Person].[BusinessEntityContact] bec 
					ON bec.[BusinessEntityID] = v.[BusinessEntityID]
					INNER JOIN [Person].ContactType ct
					ON ct.[ContactTypeID] = bec.[ContactTypeID]
					INNER JOIN [Person].[Person] p
					ON p.[BusinessEntityID] = bec.[PersonID]
				WHERE bec.[PersonID] = @PersonID;
		
		IF EXISTS(SELECT * FROM [Sales].[Store] AS s
					INNER JOIN [Person].[BusinessEntityContact] bec 
					ON bec.[BusinessEntityID] = s.[BusinessEntityID]
					WHERE bec.[PersonID] = @PersonID)
			INSERT INTO @retContactInformation
				SELECT @PersonID, p.FirstName, p.LastName, ct.[Name], 'Store Contact' 
				FROM [Sales].[Store] AS s
					INNER JOIN [Person].[BusinessEntityContact] bec 
					ON bec.[BusinessEntityID] = s.[BusinessEntityID]
					INNER JOIN [Person].ContactType ct
					ON ct.[ContactTypeID] = bec.[ContactTypeID]
					INNER JOIN [Person].[Person] p
					ON p.[BusinessEntityID] = bec.[PersonID]
				WHERE bec.[PersonID] = @PersonID;

		IF EXISTS(SELECT * FROM [Person].[Person] AS p
					INNER JOIN [Sales].[Customer] AS c
					ON c.[PersonID] = p.[BusinessEntityID]
					WHERE p.[BusinessEntityID] = @PersonID AND c.[StoreID] IS NULL) 
			INSERT INTO @retContactInformation
				SELECT @PersonID, p.FirstName, p.LastName, NULL, 'Consumer' 
				FROM [Person].[Person] AS p
					INNER JOIN [Sales].[Customer] AS c
					ON c.[PersonID] = p.[BusinessEntityID]
					WHERE p.[BusinessEntityID] = @PersonID AND c.[StoreID] IS NULL; 
		END

	RETURN;
END;
GO

--
-- Retooled:
--
CREATE FUNCTION dbo.ufnGetContactInformation(@PersonID int)
RETURNS TABLE 
AS RETURN (
-- Returns the first name, last name, job title and business entity type for the specified contact.
-- Since a contact can serve multiple roles, more than one row may be returned.

-- Returns the first name, last name, job title and business entity type for the specified contact.
-- Since a contact can serve multiple roles, more than one row may be returned.
	SELECT	e.BusinessEntityID, p.FirstName, p.LastName, e.JobTitle, 'Employee' AS BusinessEntityType
	FROM	HumanResources.Employee AS e
	INNER JOIN Person.Person p
		ON	p.BusinessEntityID = e.BusinessEntityID
	WHERE	e.BusinessEntityID = @PersonID

	UNION ALL

	SELECT	bec.PersonID, p.FirstName, p.LastName, ct.Name, 'Vendor Contact' AS BusinessEntityType
	FROM	Purchasing.Vendor AS v
	INNER JOIN Person.BusinessEntityContact bec
		ON	bec.BusinessEntityID = v.BusinessEntityID
		AND bec.PersonID = @PersonID
	INNER JOIN Person.ContactType ct
		ON	ct.ContactTypeID = bec.ContactTypeID
	INNER JOIN Person.Person p
		ON	p.BusinessEntityID = bec.PersonID

	UNION ALL

	SELECT	bec.PersonID, p.FirstName, p.LastName, ct.Name, 'Store Contact' AS BusinessEntityType
	FROM	Sales.Store AS s
	INNER JOIN Person.BusinessEntityContact bec
		ON	bec.BusinessEntityID = s.BusinessEntityID
		AND bec.PersonID = @PersonID
	INNER JOIN Person.ContactType ct
		ON	ct.ContactTypeID = bec.ContactTypeID
	INNER JOIN Person.Person p
		ON	p.BusinessEntityID = bec.PersonID

	UNION ALL

	SELECT	p.BusinessEntityID, p.FirstName, p.LastName, NULL, 'Consumer' AS BusinessEntityType
	FROM	Person.Person AS p
	INNER JOIN Sales.Customer AS c
		ON	c.PersonID = p.BusinessEntityID
		AND c.StoreID IS NULL
	WHERE	p.BusinessEntityID = @PersonID
	);
GO

--
-- Procedure that returns a query result set is a bad side-effect plus it's recursive at that!
--
CREATE PROCEDURE [dbo].[uspGetBillOfMaterials]
    @StartProductID [int],
    @CheckDate [datetime]
AS
BEGIN
    SET NOCOUNT ON;

    -- Use recursive query to generate a multi-level Bill of Material (i.e. all level 1 
    -- components of a level 0 assembly, all level 2 components of a level 1 assembly)
    -- The CheckDate eliminates any components that are no longer used in the product on this date.
    WITH [BOM_cte]([ProductAssemblyID], [ComponentID], [ComponentDesc], [PerAssemblyQty], [StandardCost], [ListPrice], [BOMLevel], [RecursionLevel]) -- CTE name and columns
    AS (
        SELECT b.[ProductAssemblyID], b.[ComponentID], p.[Name], b.[PerAssemblyQty], p.[StandardCost], p.[ListPrice], b.[BOMLevel], 0 -- Get the initial list of components for the bike assembly
        FROM [Production].[BillOfMaterials] b
            INNER JOIN [Production].[Product] p 
            ON b.[ComponentID] = p.[ProductID] 
        WHERE b.[ProductAssemblyID] = @StartProductID 
            AND @CheckDate >= b.[StartDate] 
            AND @CheckDate <= ISNULL(b.[EndDate], @CheckDate)
        UNION ALL
        SELECT b.[ProductAssemblyID], b.[ComponentID], p.[Name], b.[PerAssemblyQty], p.[StandardCost], p.[ListPrice], b.[BOMLevel], [RecursionLevel] + 1 -- Join recursive member to anchor
        FROM [BOM_cte] cte
            INNER JOIN [Production].[BillOfMaterials] b 
            ON b.[ProductAssemblyID] = cte.[ComponentID]
            INNER JOIN [Production].[Product] p 
            ON b.[ComponentID] = p.[ProductID] 
        WHERE @CheckDate >= b.[StartDate] 
            AND @CheckDate <= ISNULL(b.[EndDate], @CheckDate)
        )
    -- Outer select from the CTE
    SELECT b.[ProductAssemblyID], b.[ComponentID], b.[ComponentDesc], SUM(b.[PerAssemblyQty]) AS [TotalQuantity] , b.[StandardCost], b.[ListPrice], b.[BOMLevel], b.[RecursionLevel]
    FROM [BOM_cte] b
    GROUP BY b.[ComponentID], b.[ComponentDesc], b.[ProductAssemblyID], b.[BOMLevel], b.[RecursionLevel], b.[StandardCost], b.[ListPrice]
    ORDER BY b.[BOMLevel], b.[ProductAssemblyID], b.[ComponentID]
    OPTION (MAXRECURSION 25)
END;
GO

CREATE OR REPLACE FUNCTION dbo.udfGetBillOfMaterials (@StartProductID int, @CheckDate date)
	RETURNS TABLE
AS RETURN (
	-- Use recursive query to generate a multi-level Bill of Material (i.e. all level 1 
	-- components of a level 0 assembly, all level 2 components of a level 1 assembly)
	-- The CheckDate eliminates any components that are no longer used in the product on this date.
	WITH BOM_cte(ProductAssemblyID, ComponentID, ComponentDesc, PerAssemblyQty, StandardCost, ListPrice, BOMLevel, RecursionLevel) AS (-- CTE name and columns
		SELECT	b.ProductAssemblyID, b.ComponentID, p.Name, b.PerAssemblyQty, p.StandardCost, p.ListPrice, b.BOMLevel, CAST(0 AS smallint) -- Get the initial list of components for the bike assembly
		FROM	Production.BillOfMaterials b
		INNER JOIN Production.Product p
			ON	p.ProductID = b.ComponentID
		WHERE	b.ProductAssemblyID = @StartProductID 
			AND @CheckDate >= b.StartDate 
			AND @CheckDate <= COALESCE(b.EndDate, @CheckDate)
        UNION ALL
		SELECT	b.ProductAssemblyID, b.ComponentID, p.Name, b.PerAssemblyQty, p.StandardCost, p.ListPrice, b.BOMLevel, RecursionLevel + 1 -- Join recursive member to anchor
		FROM	BOM_cte cte
		INNER JOIN Production.BillOfMaterials b
			ON	b.ProductAssemblyID = cte.ComponentID
		INNER JOIN Production.Product p
			ON	p.ProductID = b.ComponentID
		WHERE	@CheckDate >= b.StartDate
			AND @CheckDate <= COALESCE(b.EndDate, @CheckDate)
        )
	-- Outer select from the CTE
	SELECT	b.ProductAssemblyID, b.ComponentID, b.ComponentDesc, SUM(b.PerAssemblyQty) AS TotalQuantity , b.StandardCost, b.ListPrice, b.BOMLevel, b.RecursionLevel
	FROM	BOM_cte b
	GROUP BY b.ComponentID, b.ComponentDesc, b.ProductAssemblyID, b.BOMLevel, b.RecursionLevel, b.StandardCost, b.ListPrice
	--ORDER BY b.BOMLevel, b.ProductAssemblyID, b.ComponentID
	OPTION (MAXRECURSION 25)
	);
GO

CREATE OR ALTER FUNCTION dbo.udfGetBillOfMaterials (@StartProductID int, @CheckDate date)
	RETURNS @OutputSet TABLE (
			ProductAssemblyID int,
			ComponentID int,
			ComponentDesc Name,
			TotalQuantity decimal(8,2),
			StandardCost money,
			ListPrice money,
			BOMLevel smallint,
			RecursionLevel smallint
			)
AS BEGIN
	DECLARE @ResultSet TABLE (
			ProductAssemblyID int,
			ComponentID int,
			ComponentDesc Name,
			PerAsemblyQty decimal(8,2),
			StandardCost money,
			ListPrice money,
			BOMLevel smallint,
			RecursionLevel smallint
			)
	DECLARE @i int = 0;

	-- Use loop to generate a multi-level Bill of Material (i.e. all level 1 
	-- components of a level 0 assembly, all level 2 components of a level 1 assembly)
	-- The CheckDate eliminates any components that are no longer used in the product on this date.
	INSERT INTO @ResultSet(ProductAssemblyID, ComponentID, ComponentDesc, PerAssemblyQty, StandardCost, ListPrice, BOMLevel, RecursionLevel) -- CTE name and columns
	SELECT	b.ProductAssemblyID, b.ComponentID, p.Name, b.PerAssemblyQty, p.StandardCost, p.ListPrice, b.BOMLevel, CAST(0 AS smallint) AS RecursionLevel-- Get the initial list of components for the bike assembly
	FROM	Production.BillOfMaterials b
	INNER JOIN Production.Product p
		ON	p.ProductID = b.ComponentID
	WHERE	b.ProductAssemblyID = @StartProductID 
		AND @CheckDate >= b.StartDate 
		AND @CheckDate <= COALESCE(b.EndDate, @CheckDate)

	WHILE @@ROWCOUNT > 0 AND @i < 25 BEGIN
		SET @i += 1;

		INSERT INTO @ResultSet(ProductAssemblyID, ComponentID, ComponentDesc, PerAssemblyQty, StandardCost, ListPrice, BOMLevel, RecursionLevel)
		SELECT	b.ProductAssemblyID, b.ComponentID, p.Name, b.PerAssemblyQty, p.StandardCost, p.ListPrice, b.BOMLevel, RecursionLevel + 1 -- Join recursive member to anchor
		FROM	@ResultSet cte
		INNER JOIN Production.BillOfMaterials b
			ON	b.ProductAssemblyID = cte.ComponentID
		INNER JOIN Production.Product p
			ON	p.ProductID = b.ComponentID
		WHERE	@CheckDate >= b.StartDate
			AND @CheckDate <= COALESCE(b.EndDate, @CheckDate)
	END

	-- Outer select from the CTE
	INSERT INTO @OutputSet(ProductAssemblyID, ComponentID, ComponentDesc, TotalQuantity, StandardCost, ListPrice, BOMLevel, RecursionLevel)
	SELECT	b.ProductAssemblyID, b.ComponentID, b.ComponentDesc, SUM(b.PerAssemblyQty) AS TotalQuantity , b.StandardCost, b.ListPrice, b.BOMLevel, b.RecursionLevel
	FROM	@ResultSet b
	GROUP BY b.ComponentID, b.ComponentDesc, b.ProductAssemblyID, b.BOMLevel, b.RecursionLevel, b.StandardCost, b.ListPrice
	--ORDER BY b.BOMLevel, b.ProductAssemblyID, b.ComponentID
	;
END
GO