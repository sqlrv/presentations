-- Data Rows
SELECT s.StringValue
FROM (VALUES(1,'One'),(2,'Two'),(3,'Three'),(4,'Four'),(5,'Five')) AS s(SortOrder,StringValue)
ORDER BY s.SortOrder;

-- Tally table Rows
SELECT t.n
FROM (VALUES(1),(2),(3),(4),(5),(6),(7),(8),(9),(10)) AS t(n)
ORDER BY t.n;

-- Data Rows cross joined with tally table rows
SELECT t.n, s.StringValue
FROM (VALUES(1,'One'),(2,'Two'),(3,'Three'),(4,'Four'),(5,'Five')) AS s(SortOrder,StringValue)
CROSS JOIN (VALUES(1),(2),(3),(4),(5),(6),(7),(8),(9),(10)) AS t(n)
ORDER BY s.SortOrder, t.n;

-- Limit results to where n is the number of characters in the string
SELECT t.n, s.StringValue
FROM (VALUES(1,'One'),(2,'Two'),(3,'Three'),(4,'Four'),(5,'Five')) AS s(SortOrder,StringValue)
CROSS JOIN (VALUES(1),(2),(3),(4),(5),(6),(7),(8),(9),(10)) AS t(n)
WHERE t.n <= LEN(s.StringValue)
ORDER BY t.n, s.SortOrder;

-- Same as above, alternate method
SELECT t.n, s.StringValue
FROM (VALUES(1,'One'),(2,'Two'),(3,'Three'),(4,'Four'),(5,'Five')) AS s(SortOrder,StringValue)
INNER JOIN (VALUES(1),(2),(3),(4),(5),(6),(7),(8),(9),(10)) AS t(n)
    ON t.n <= LEN(s.StringValue)
ORDER BY t.n, s.SortOrder;

-- Making use of tally rows to "loop" through strings and highlight each letter
SELECT t.n, CASE WHEN t.n = 1 THEN '' ELSE LEFT(s.StringValue, t.n-1) END + '>' + SUBSTRING(s.StringValue, t.n, 1) + '<' + CASE WHEN t.n = LEN(s.StringValue) THEN '' ELSE SUBSTRING(s.StringValue, t.n+1, 8000) END AS StringValue
FROM (VALUES(1,'One'),(2,'Two'),(3,'Three'),(4,'Four'),(5,'Five')) AS s(SortOrder,StringValue)
CROSS JOIN (VALUES(1),(2),(3),(4),(5),(6),(7),(8),(9),(10)) AS t(n)
WHERE t.n <= LEN(s.StringValue)
ORDER BY s.SortOrder, t.n;
GO

/*
 * Function: fnGenerate_Series
 *     Returns a table of sequence values based on the parameters
 * Parameters:  
 *     @StartVal : The starting value
 *     @StopVal  : The ending value
 *     @StepVal  : The incremental value (can be negative as well)
 */
CREATE OR ALTER FUNCTION dbo.fnGenerate_Series(
        @StartVal BIGINT = 1,
        @StopVal  BIGINT = 0,
        @StepVal  BIGINT = 1
		)
RETURNS TABLE WITH SCHEMABINDING
AS RETURN
    WITH e1(n) AS (SELECT n FROM (VALUES (1),(1),(1),(1),(1),(1),(1),(1),(1),(1),(1),(1),(1),(1),(1),(1)) AS x(n)) -- 16 records
        ,e4(n) AS (SELECT 1 FROM e1 a CROSS JOIN e1 b CROSS JOIN e1 c CROSS JOIN e1 d) -- 16^4 or 65,536 records (256*256)
       ,e15(n) AS (SELECT 1 FROM e4 a CROSS JOIN e4 b CROSS JOIN e4 c CROSS JOIN e1 d CROSS JOIN e1 e CROSS JOIN e1 f) -- 16^15 or 1,152,921,504,606,846,976 records
        ,ex(n) AS (SELECT 1 FROM e15 a CROSS JOIN (VALUES (1),(1),(1),(1),(1),(1),(1),(1)) x(n))
      ,emax(n) AS (SELECT TOP ((CASE WHEN @StopVal > @StartVal THEN @StopVal - @StartVal ELSE @StartVal - @StopVal END + ABS(@StepVal)) / ABS(@StepVal))
							  ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS n
				   FROM   ex
				   ) -- 16^15*8 (2^63) or 9,223,372,036,854,775,807 records (largest size for a BIGINT value) -- over 9 quintillion!!
    SELECT ((n - 1) * @StepVal) + @StartVal as value
    FROM   emax
    WHERE  ((n - 1) * @StepVal) + @StartVal BETWEEN
				CASE WHEN @StopVal > @StartVal THEN @StartVal ELSE @StopVal END
			AND CASE WHEN @StopVal > @StartVal THEN @StopVal ELSE @StartVal END;
GO

-- Create a list of people with birthdates
DROP TABLE IF EXISTS dbo.PersonList;
CREATE TABLE dbo.PersonList (
		PersonID INT,
		FirstName VARCHAR(32),
		LastName VARCHAR(32),
		DOB DATE,
		Department VARCHAR(32),
		ManagerID INT
		);

INSERT INTO dbo.PersonList (PersonID, LastName, FirstName, DOB, Department, ManagerID)
VALUES	(123456, 'Duck', 'Daffy', '03/05/1964', 'Finance', 649731),
		(234567, 'Bunny', 'Bugs', '02/29/1964', 'Quality Assurance', 456789),
		(345678, 'Coyote', 'Wile', '01/15/1966', 'Engineering', 649731),
		(456789, 'Runner', 'Road', '04/23/1974', 'Quality Assurance', 345678),
		(567890, 'Duck', 'Daisy', '05/03/1966', 'Administration', 649731),
		(649731, 'McDuck', 'Scrooge', '04/04/1944', 'Administration', NULL),
		(564231, 'Fudd', 'Elmer', '03/20/1946', 'Engineering', 345678),
		(853156, 'Bird', 'Tweety', '10/10/1960', 'Quality Assurance', 456789),
		(462137, 'Cat', 'Sylvester', '12/15/1955', 'Engineering', 345678),
		(134679, 'LePue', 'Peppy', '11/11/1959', 'Administration', 649731),
		(963741, 'Duck', 'Huey', '09/09/1979', 'Finance', 123456),
		(963742, 'Duck', 'Louie', '09/09/1979', 'Finance', 123456),
		(963743, 'Duck', 'Dewey', '09/09/1979', 'Finance', 123456);

-- Identify the months that have birthdates
SELECT DATEPART(mm, DOB) AS [Month], COUNT(1) AS [Count]
FROM dbo.PersonList
GROUP BY DATEPART(mm, DOB)
ORDER BY 1;

-- Identify all months in the year and the birthdates
SELECT t.value AS [Month], COUNT(DATEPART(mm, pl.DOB)) AS [Count]
FROM Generate_Series(1, 12) t
LEFT JOIN dbo.PersonList pl
    ON t.value = DATEPART(mm, pl.DOB)
GROUP BY t.value;

-- Generate a date table for the current millenium with various information
DECLARE @StartDate DATE = '01-Jan-2000',
        @EndDate DATE = '31-Dec-2999';

WITH cteDateValue(n, TheDate) AS (
	SELECT	gs.value, DATEADD(DAY, gs.value, @StartDate) AS TheDate
	FROM Generate_Series(0, DATEDIFF(DAY, @StartDate, @EndDate)) AS gs
	)
SELECT	n, TheDate AS [Date],
		DATENAME(WEEKDAY, TheDate) AS [DayName],
		DAY(TheDate) AS [Day],
		DATEPART(DAYOFYEAR, TheDate) AS [DayOfYear],
		CAST(CASE WHEN DATEPART(WEEKDAY, TheDate) IN (CASE @@DATEFIRST WHEN 1 THEN 6 WHEN 7 THEN 1 END,7) THEN 1 ELSE 0 END AS BIT) AS [IsWeekend],
		CAST(CASE WHEN MONTH(TheDate) = 2 AND DAY(TheDate) = 29 THEN 1 ELSE 0 END AS BIT) AS IsLeapDay,
		DATEPART(WEEK, TheDate) AS [Week],
		MONTH(TheDate) AS [Month],
		DATENAME(MONTH, TheDate) AS [MonthName],
		DATEFROMPARTS(YEAR(TheDate), MONTH(TheDate), 1) AS [FirstOfMonth],
		DATEADD(DAY, -1, DATEADD(MONTH, 1, DATEFROMPARTS(YEAR(TheDate), MONTH(TheDate), 1))) AS [LastOfMonth],
		DATEPART(QUARTER, TheDate) AS [Quarter],
		YEAR(TheDate) AS [Year],
		DATEFROMPARTS(YEAR(TheDate), 1, 1) AS [FirstOfYear],
		DATEFROMPARTS(YEAR(TheDate), 12, 31) AS [LastOfYear],
		CAST(CASE WHEN YEAR(TheDate) % 4 = 0 THEN 1 ELSE 0 END AS BIT) AS IsLeapYear
FROM cteDateValue;

--
-- Replacing Loops
--

-- Typical procedural method
DECLARE @TopLimit INT = 1000,
        @i INT,
        @n INT = 0;
DECLARE @PrimeList TABLE (n INT, isPrime BIT);

WHILE @n < @TopLimit BEGIN
    SET @n += 1;
    INSERT INTO @PrimeList(n, isPrime)
    SELECT @n, 1;		-- Initially set all as potential prime
END

SELECT @n = 2;		-- Start with the first known prime
WHILE @n <= @TopLimit BEGIN
    SET @i = @n * @n;	-- Start with the square of the prime number
    WHILE @i <= @TopLimit BEGIN
        UPDATE	@PrimeList
            SET IsPrime = 0	-- Set multiples of the prime as NOT prime
        WHERE	n = @i;
        SET @i += @n;	-- Increment by the prime number
    END
    SELECT	@n = MIN(n)	-- Go to the next known prime number
    FROM	@PrimeList
    WHERE	n > @n
        AND IsPrime = 1;
END

SELECT	n AS Prime
FROM	@PrimeList
WHERE	IsPrime = 1
ORDER BY n;

-- Tally method (set-based)
SELECT	n1.value AS Prime
FROM	Generate_Series(1, 1000) AS n1
WHERE NOT EXISTS (							-- Correlated sub-query
    SELECT	1
    FROM	Generate_Series(1, 999) AS n2
    WHERE	n2.value+1 < n1.value	-- Only need to test numbers less than the current number
        AND n1.value % (n2.value+1) = 0	-- Check to see if there are any numbers that evenly divide in
    )
ORDER BY n1.value;
