﻿
-- Create a list of people with birthdates
DROP TABLE IF EXISTS dbo.PersonList;
CREATE TABLE dbo.PersonList (
		PersonID INT,
		FirstName VARCHAR(32),
		LastName VARCHAR(32),
		DOB DATE,
		Department VARCHAR(32),
		ManagerID INT
		);

INSERT INTO dbo.PersonList (PersonID, LastName, FirstName, DOB, Department, ManagerID)
VALUES	(123456, 'Duck', 'Daffy', '03/05/1964', 'Finance', 649731),
		(234567, 'Bunny', 'Bugs', '02/29/1964', 'Quality Assurance', 456789),
		(345678, 'Coyote', 'Wile', '01/15/1966', 'Engineering', 649731),
		(456789, 'Runner', 'Road', '04/23/1974', 'Quality Assurance', 345678),
		(567890, 'Duck', 'Daisy', '05/03/1966', 'Administration', 649731),
		(649731, 'McDuck', 'Scrooge', '04/04/1944', 'Administration', NULL),
		(564231, 'Fudd', 'Elmer', '03/20/1946', 'Engineering', 345678),
		(853156, 'Bird', 'Tweety', '10/10/1960', 'Quality Assurance', 456789),
		(462137, 'Cat', 'Sylvester', '12/15/1955', 'Engineering', 345678),
		(134679, 'LePue', 'Peppy', '11/11/1959', 'Administration', 649731),
		(963741, 'Duck', 'Huey', '09/09/1979', 'Finance', 123456),
		(963742, 'Duck', 'Louie', '09/09/1979', 'Finance', 123456),
		(963743, 'Duck', 'Dewey', '09/09/1979', 'Finance', 123456);

--
-- Typical Recursive CTE Approach
--
WITH cte_Employee AS (
	SELECT	PersonID,
            FirstName,
            LastName,
            ManagerID,
            0 AS Level
    FROM    dbo.PersonList
    WHERE   ManagerID IS NULL
    UNION ALL
	SELECT	p.PersonID,
            p.FirstName,
            p.LastName,
            p.ManagerID,
            s.Level + 1
    FROM    dbo.PersonList p
	INNER JOIN cte_Employee s
		ON  s.PersonID = p.ManagerID
	)
SELECT  s.PersonID AS EmployeeID,
		s.FirstName AS Employee_FirstName,
		s.LastName AS Employee_LastName,
		m.PersonID AS ManagerID,
		m.FirstName AS Manager_FirstName,
		m.LastName AS Manager_LastName,
		s.Level
FROM	cte_Employee s
LEFT JOIN dbo.PersonList m
	ON  m.PersonID = s.ManagerID
ORDER BY s.Level, m.PersonID, s.PersonID;

--
-- Non-Recursive CTE Approach
--
DECLARE @i INT = 0;

-- Create a table to track results
DROP TABLE IF EXISTS dbo.ResutlSet;
CREATE TABLE dbo.ResultSet (
		EmployeeID INT,
		Employee_FirstName VARCHAR(32),
		Employee_LastName VARCHAR(32),
		ManagerID INT,
		Manager_FirstName VARCHAR(32),
		Manager_LastName VARCHAR(32),
		Level INT
		);

--
-- Process the "Base" case
--
INSERT INTO dbo.ResultSet(EmployeeID, Employee_FirstName, Employee_LastName, Level)
SELECT	PersonID, FirstName, LastName, 0
FROM	dbo.PersonList
WHERE	ManagerID IS NULL;

--
-- Process each of the subsequent levels
--
WHILE @@ROWCOUNT > 0 BEGIN
	SET @i += 1;

	INSERT INTO dbo.ResultSet(EmployeeID, Employee_FirstName, Employee_LastName, ManagerID, Manager_FirstName, Manager_LastName, Level)
	SELECT	p.PersonID, p.FirstName, p.LastName, m.EmployeeID, m.Employee_FirstName, m.Employee_LastName, @i
	FROM	dbo.PersonList p
	INNER JOIN dbo.ResultSet m
		ON	m.Level = @i-1
		AND m.EmployeeID = p.ManagerID;
END

--
-- Display the results
--
SELECT	EmployeeID, Employee_FirstName, Employee_LastName, ManagerID, Manager_FirstName, Manager_LastName, Level
FROM	dbo.ResultSet
ORDER BY Level, ManagerID, EmployeeID;