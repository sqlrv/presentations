--
--  Last Value Issue
--
	DECLARE @NameSet TABLE (Name VARCHAR(16));
	INSERT INTO @NameSet (Name)
	VALUES ('Jenn'),('Neil'),('Tom'),('Sally'),('Joe'),('Savpril');

	DECLARE @MyName VARCHAR(MAX);

	SELECT	@MyName = Name
	FROM	@NameSet;

	SELECT @MyName;
GO

--
-- String concatenation methods
--
	DECLARE @NameSet TABLE (Name VARCHAR(16));
	INSERT INTO @NameSet (Name)
	VALUES ('Jenn'),('Neil'),('Tom'),('Sally'),('Joe'),('Savpril');

	-- Typical method
	DECLARE @NameList_Loop VARCHAR(MAX);

	SELECT	@NameList_Loop = ISNULL(@NameList_Loop + ', ', '') + Name
	FROM	@NameSet;

	SELECT	@NameList_Loop;
GO

--
-- FOR XML / STUFF method
--
	DECLARE @NameSet TABLE (Name VARCHAR(16));
	INSERT INTO @NameSet (Name)
	VALUES ('Jenn'),('Neil'),('Tom'),('Sally'),('Joe'),('Savpril');

	DECLARE @NameList_Set VARCHAR(MAX);

	SELECT	@NameList_Set = STUFF(( SELECT	', ' + Name
									FROM	@NameSet
									FOR XML PATH(''), TYPE).value('.', 'VARCHAR(MAX)')
									, 1, 2, '');

	SELECT	@NameList_Set;
GO

--
-- STRING_AGG method
--
	DECLARE @NameSet TABLE (Name VARCHAR(16));
	INSERT INTO @NameSet (Name)
	VALUES ('Jenn'),('Neil'),('Tom'),('Sally'),('Joe'),('Savpril');

	DECLARE @NameList_Agg NVARCHAR(MAX);

	SELECT	@NameList_Agg = STRING_AGG(Name, ', ')
	FROM	@NameSet;

	SELECT	@NameList_Agg;
GO
--
-- Scalar Function Calls
--
	--
	-- Scalar Function example query
	--
	CREATE OR ALTER FUNCTION dbo.sfEscape_Like_WildCards (@pattern NVARCHAR(MAX))
	RETURNS NVARCHAR(MAX)
	AS BEGIN
		SET @pattern = REPLACE(@pattern, '(', '[(]');
		SET @pattern = REPLACE(@pattern, ')', '[)]');
		SET @pattern = REPLACE(@pattern, '%', '[%]');
		SET @pattern = REPLACE(@pattern, '_', '[_]');

		RETURN @pattern;
	END
GO
	DECLARE @NameSet TABLE (Name VARCHAR(16));
	INSERT INTO @NameSet (Name)
	VALUES ('Jenn%'),('Neil_'),('T(om)');

	SELECT	Name, dbo.sfEscape_Like_WildCards(Name) AS NewValue
	FROM	@NameSet;
GO
	--
	-- Table-Valued Function example query
	--
	CREATE OR ALTER FUNCTION dbo.tfEscape_Like_WildCards (@pattern NVARCHAR(MAX))
	RETURNS TABLE WITH SCHEMABINDING
	AS RETURN
		SELECT REPLACE(REPLACE(REPLACE(REPLACE(@pattern, N'(', N'[(]'), N')', N'[)]'), N'%', N'[%]'), N'_', N'[_]') AS NewValue;
GO
	DECLARE @NameSet TABLE (Name VARCHAR(16));
	INSERT INTO @NameSet (Name)
	VALUES ('Jenn%'),('Neil_'),('T(om)');

	SELECT	ns.Name, fn.NewValue
	FROM	@NameSet AS ns
	CROSS APPLY dbo.tfEscape_Like_WildCards(ns.Name) AS fn;
GO

--
-- GO Loops
--
	IF OBJECT_ID(N'tempdb..#TestData', N'U') IS NOT NULL DROP TABLE #TestData;
	CREATE TABLE #TestData(ID INT IDENTITY(1,1), DataGUID UNIQUEIDENTIFIER);

	-- Usual method
	-- This method performs a loop of 100 INSERT INTO statements
	INSERT INTO #TestData (DataGUID) VALUES (NEWID());
	GO 100

	-- Tally method
	-- This method performs a single INSERT INTO statement in set-based method
	TRUNCATE TABLE #TestData;
	INSERT INTO #TestData(DataGUID)
	SELECT NEWID()
	FROM dbo.fnTally(100, 1);
	GO
