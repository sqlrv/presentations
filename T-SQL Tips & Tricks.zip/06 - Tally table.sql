USE [TipsTricks];

--=============================================================================
--      Create and populate a Tally table
--=============================================================================
--===== Conditionally drop 
     IF OBJECT_ID('dbo.Tally') IS NOT NULL DROP TABLE dbo.Tally;

--===== Create and populate the Tally table
 SELECT TOP 100 IDENTITY(INT,1,1) AS N
   INTO dbo.Tally
   FROM Master.dbo.SysColumns;

/*
-- For over to 4 million records, do the following:
 SELECT TOP 100 IDENTITY(INT,1,1) AS N
   INTO dbo.Tally
   FROM Master.dbo.SysColumns sc1,
		Master.dbo.SysColumns sc2;

--===== Add a Primary Key to maximize performance
  ALTER TABLE dbo.Tally
    ADD CONSTRAINT PK_Tally_N 
        PRIMARY KEY CLUSTERED (N) WITH FILLFACTOR = 100;

--===== Let the public use it
  GRANT SELECT, REFERENCES ON dbo.Tally TO PUBLIC;
*/
GO

-- Create as a table function utilizing increasing exponential growth
-- Advantage is that this is in memory only with no disk I/O required
CREATE FUNCTION dbo.fnTally(@n int)
RETURNS TABLE WITH SCHEMABINDING
AS RETURN
	WITH e1(n) AS (SELECT n FROM (VALUES (1),(1),(1),(1),(1),(1),(1),(1),(1),(1)) AS x(n)) -- 10 records
		,e2(n) AS (SELECT 1 FROM e1 a, e1 b) -- 100 records (10*10)
		,e4(n) AS (SELECT 1 FROM e2 a, e2 b) -- 10,000 records (100*100)
		,e8(n) AS (SELECT 1 FROM e4 a, e4 b) -- 100,000,000 records (10,000*10,000)
	SELECT TOP (@n) ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) AS N
	FROM e8; -- Adjust selection as needed
GO

/*
Example 1:	Let's say that you need to generate a list of all dates from 05/12/2008 to 06/02/2008
			inclusive. You might use a temp table or table variable, and construct a loop that
			inserts records for each date in the range. By using a tally table, all you need is
			this (using variables to make it flexible):
*/
DECLARE @start date = '05/12/2008', @end date = '06/02/2008';

SELECT DATEADD(d, (N - 1), @start) AS [Date]
FROM dbo.Tally
WHERE N < DATEDIFF(d, @start, @end) + 1;

/*
Example 2:	I want to find out how many people have a birthday in each month but I don't want to
			skip any months.
*/

--Normally I'd use this query
WITH cteBirthday(PatientID, DOB_Month) AS (
	SELECT PatientID, DATEPART(mm, DOB)
	FROM dbo.tbl_Patients
	)
SELECT b.DOB_Month as 'Month', COUNT(*)
FROM cteBirthday b
GROUP BY b.DOB_Month;

-- However, this will not return a row for any month that did not have a birthday.  You can use a
-- tally to ensure that you have totals for all 12 months, even for months without a birthday.

WITH cteBirthday(PatientID, DOB_Month) AS (
	SELECT PatientID, DATEPART(mm, DOB)
	FROM dbo.tbl_Patients
	)
SELECT t.N as 'Month', COUNT(DOB_Month)
FROM dbo.fnTally(12) t
	LEFT JOIN cteBirthday b on t.N = b.DOB_Month
WHERE t.N <= 12
GROUP BY t.N;

--
-- Bonus Example:
--		Break strings into multiple segments of a given length or less
--
	declare @len smallint = 100;

	with cteStringValues(StringId, StringValue) AS (
		select StringId, StringValue
		from (values (1,'Three Irishmen, Paddy, Sean and Seamus, were stumbling home from the pub late one night and found themselves on the road which led past the old graveyard. "Come have a look over here," says Paddy, "It''s Michael O''Grady''s grave, God bless his soul. He lived to the ripe old age of 87."'),
					 (2,'"That''s nothing," says Sean, "here''s one named Patrick O''Toole, it says here that he was 95 when he died."'),
					 (3,'Just then, Seamus yells out, "Good God, here''s a fella that got to be 145!"'),
					 (4,'"What was his name?" asks Paddy.'),
					 (5,'Seamus stumbles around a bit, awkwardly lights a match to see what else is written on the stone marker, and exclaims, "Miles, from Dublin."')) as x(StringId,StringValue)
		)
	select StringId, n as SeqNbr, substring(StringValue, ((n-1)*@len)+1, @len) as StringFragment
	from cteStringValues s
	cross apply dbo.fnTally(10) t
	where len(StringValue) - ((n-1)*@len) > 0
	order by StringId, n;