USE [TipsTricks];

IF OBJECT_ID('dbo.tbl_Enum_LogType') IS NOT NULL DROP TABLE dbo.tbl_Enum_LogType;
CREATE TABLE dbo.tbl_Enum_LogType
(
	[LogTypeId] TINYINT NOT NULL PRIMARY KEY, 
    [Name] VARCHAR(128) NOT NULL, 
    [Label] VARCHAR(128) NULL, 
    [Description] VARCHAR(512) NULL
)
GO

-- Typical values for tbl_Enum_LogType
INSERT INTO dbo.tbl_Enum_LogType (LogTypeId, Name, Label, Description)
VALUES	(1,'Fatal','Fatal Errors', 'Fatal system errors outside of application'),
		(2,'Error','Non-fatal Errors','Application errors, crashes, or exceptions'),
		(3,'Warn','Warnings','Incorrect behavior but the application can continue'),
		(4,'Info','Informational Messages','Normal activity behavior'),
        (5,'Trace','Trace Messages','Procedure begin/end or major procedure activity'),
		(6,'Debug','Debug Messages','Activity within procedure more granular than a trace'),
		(7,'Stats','Query Statistics','Capture statistics for individual queries');

IF OBJECT_ID('dbo.tbl_LogStart') IS NOT NULL DROP TABLE dbo.tbl_LogStart;
CREATE TABLE dbo.tbl_LogStart
(
	[LogMsgId] BIGINT NOT NULL PRIMARY KEY IDENTITY, 
    [StartDateTime] DATETIME NOT NULL, 
    [ProcName] VARCHAR(256) NOT NULL, 
    [LogTypeId] TINYINT NOT NULL,
    [Description] VARCHAR(512) NULL, 
    [Message] VARCHAR(8000) NULL, 
	[SysUser] VARCHAR(256) NULL,
    CONSTRAINT FK_tbl_LogStart_tbl_Enum_Log_Type
		FOREIGN KEY (LogTypeId)
		REFERENCES dbo.tbl_Enum_LogType (LogTypeId)
)
GO

IF OBJECT_ID('dbo.tbl_LogStop') IS NOT NULL DROP TABLE dbo.tbl_LogStop;
CREATE TABLE dbo.tbl_LogStop
(
	[LogMsgId] BIGINT NOT NULL PRIMARY KEY, 
    [StopDateTime] DATETIME NOT NULL, 
    [RowCnt] BIGINT NULL, 
    [Message] VARCHAR(8000) NULL,
    CONSTRAINT FK_tbl_LogStop_tbl_LogStart
		FOREIGN KEY (LogMsgId)
		REFERENCES dbo.tbl_LogStart (LogMsgId)
)
GO

-- =============================================
-- Author:		Aaron N. Cutshall
-- Create Date: 29-Sep-2011
-- Description:	Start a log message and return its ID
-- =============================================
IF OBJECT_ID('dbo.usp_LogStart') IS NOT NULL DROP PROCEDURE dbo.usp_LogStart;
GO
CREATE PROCEDURE dbo.usp_LogStart
    @ProcName varchar(256),
	@LogTypeId tinyint,
	@Description varchar(512),
	@ErrorMsg varchar(8000),
	@LogMsgID bigint OUTPUT 
AS
BEGIN
	SET NOCOUNT ON;

	BEGIN TRY
	    INSERT INTO dbo.tbl_LogStart (
			[StartDateTime],
			[ProcName],
			[LogTypeId],
			[Description],
			[Message],
			[SysUser]
			)
		VALUES (
			GETDATE(),
			@ProcName,
			@LogTypeId,
			@Description,
			@ErrorMsg,
			SYSTEM_USER
			)

		SELECT @LogMsgID = SCOPE_IDENTITY();

		IF @@ERROR <> 0
			RAISERROR('Error inserting into log.tbl_LogStart', -- Error message
					16, -- Error Severity				
					1); -- Error State			 
	END TRY
	BEGIN CATCH
		DECLARE @ErrorMessage varchar(8000) = ERROR_MESSAGE(),
				@ErrorSeverity int = ERROR_SEVERITY(),
				@ErrorState int = ERROR_STATE();

		IF @@TRANCOUNT > 0 ROLLBACK;

		RAISERROR (@ErrorMessage, @ErrorSeverity, @ErrorState);
	END CATCH
END
GO

-- =============================================
-- Author:		Aaron N. Cutshall
-- Create date: 29-Sep-2011
-- Description:	Complete a log message
-- =============================================
IF OBJECT_ID('dbo.usp_LogStop') IS NOT NULL DROP PROCEDURE dbo.usp_LogStop;
GO
CREATE PROCEDURE dbo.usp_LogStop
	@LogMsgId    bigint,
	@RowCnt      bigint = NULL,
	@ErrorMsg    varchar(8000) = NULL
AS
BEGIN
	SET NOCOUNT ON;

	BEGIN TRY
	    INSERT INTO dbo.tbl_LogStop (
			LogMsgId,
			StopDateTime,
			RowCnt,
			[Message]
			)
		VALUES (
			@LogMsgId,
			GETDATE(),
			@RowCnt,
			@ErrorMsg
			)

		IF @@ERROR <> 0
			RAISERROR('Error inserting into log.tbl_LogStop', -- Error message
					16, -- Error Severity				
					1); -- Error State			 
	END TRY
	BEGIN CATCH
		DECLARE @ErrorMessage varchar(2048) = ERROR_MESSAGE(),
				@ErrorSeverity int = ERROR_SEVERITY(),
				@ErrorState int = ERROR_STATE();

		IF @@TRANCOUNT > 0 ROLLBACK;

		RAISERROR (@ErrorMessage, @ErrorSeverity, @ErrorState);
	END CATCH
END
GO

-- =============================================
-- Author:		Aaron N. Cutshall
-- Create date: 29-Sep-2011
-- Description:	Complete a log message
-- =============================================
IF OBJECT_ID('dbo.vw_System_Log') IS NOT NULL DROP VIEW dbo.vw_System_Log;
GO
CREATE VIEW dbo.vw_System_Log AS
	SELECT a.LogMsgId, a.ProcName, a.SysUser, a.LogTypeId, a.[Description], a.StartDateTime, b.StopDateTime,
			CASE WHEN b.StopDateTime IS NULL THEN NULL ELSE b.StopDateTime - a.StartDateTime END AS ElapsedTime,
			b.RowCnt, ISNULL(b.[Message], a.[Message]) AS ErrorMsg
	FROM dbo.tbl_LogStart a
	LEFT JOIN dbo.tbl_LogStop b
		ON b.LogMsgId = a.LogMsgId;

--	Usage Example:

	SET NOCOUNT ON;
    DECLARE @SPName varchar(256) = 'Test Procedure', -- OBJECT_SCHEMA_NAME(@@PROCID) + '.' + OBJECT_NAME(@@PROCID),
            @LogMsgId_Trace bigint,
            @LogMsgId_Stats bigint,
			@LogTypeId_Trace tinyint,
            @LogTypeId_Stats tinyint,
			@LogLevelId tinyint, -- Typically passed in as a parameter or pulled from a table per procedure name
			@MsgString varchar(512),
			@RowCnt bigint;

	SELECT @LogTypeId_Trace = LogTypeId FROM dbo.tbl_Enum_LogType WHERE Name = 'Trace';
	SELECT @LogTypeId_Stats = LogTypeId FROM dbo.tbl_Enum_LogType WHERE Name = 'Stats';
	SELECT @LogLevelId = LogTypeId FROM dbo.tbl_Enum_LogType WHERE Name = 'Info'; -- Typically passed in as a parameter or pulled from a table per procedure name

	SET @MsgString = 'Process ' + @SPName + '...';
	IF @LogLevelId >= @LogTypeId_Trace
			EXEC dbo.usp_LogStart @SPName, @LogTypeId_Trace, @MsgString, NULL, @LogMsgId_Trace OUTPUT;

	SET @MsgString = 'Run test query';
	IF @LogLevelId >= @LogTypeId_Stats
		EXEC dbo.usp_LogStart @SPName, @LogTypeId_Stats, @MsgString, NULL, @LogMsgId_Stats OUTPUT;
	SELECT * FROM sys.syscolumns;
	SET @RowCnt = @@ROWCOUNT;

	IF @LogLevelId >= @LogTypeId_Stats
		EXEC dbo.usp_LogStop @LogMsgId_Stats, @RowCnt;

	IF @LogLevelId >= @LogTypeId_Trace
		EXEC dbo.usp_LogStop @LogMsgId_Trace;
GO
-- Display system log messages
SELECT * FROM dbo.vw_System_Log ORDER BY LogMsgId;