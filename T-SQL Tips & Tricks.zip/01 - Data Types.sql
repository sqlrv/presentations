USE [TipsTricks];

--
-- Example #1: Simple Variable (numeric) with Execution Plan
--
DECLARE 
	@MySmallInt SMALLINT = 5,
	@MyBigInt BIGINT = 5;

-- Examine the execution plan of the following:
SELECT 'Matching Types'
WHERE @MySmallInt = @MySmallInt;

-- Compare to exeuction plan of the following:
SELECT 'Mismatched Types'
WHERE @MySmallInt = @MyBigInt;
GO

--
-- Example #2: Simple Variable (string) with Execution Plan
--
DECLARE 
	@MyNVarChar NVARCHAR(50) = 'This is a string',
	@MyVarChar VARCHAR(50) = 'This is a string';

-- Examine the execution plan of the following:
SELECT 'Matching Types'
WHERE @MyVarChar = @MyVarChar;

-- Compare to exeuction plan of the following:
SELECT 'Mismatched Types'
WHERE @MyNVarChar = @MyVarChar;
GO

--
-- Example #3: More complex with tables with Execution Plan
--
IF OBJECT_ID('dbo.tbl_DataType_A') IS NOT NULL DROP TABLE dbo.tbl_DataType_A;
CREATE TABLE dbo.tbl_DataType_A (
	Field_A smallint,
	Field_B varchar(64)
	);

IF OBJECT_ID('dbo.tbl_DataType_B') IS NOT NULL DROP TABLE dbo.tbl_DataType_B;
CREATE TABLE dbo.tbl_DataType_B (
	Field_A int,
	Field_B nvarchar(64)
	);

/* Bonus Tips:
	1. Always fully qualify table names (schema.tablename)
	2. Always specify fields for an insert
	3. Always use and alias even with a single table
*/
INSERT INTO dbo.tbl_DataType_A(Field_B, Field_A)
	SELECT sc.name, ROW_NUMBER() OVER(ORDER BY sc.name)
	FROM master.dbo.syscolumns sc
	WHERE sc.name > 'A';

INSERT INTO dbo.tbl_DataType_B(Field_A, Field_B)
	SELECT a.Field_A, a.Field_B
	FROM dbo.tbl_DataType_A a;

DECLARE @MyUpperLimit varchar(5);
SET @MyUpperLimit = 20;
SELECT @MyUpperLimit;

SELECT a.Field_A, a.Field_B
FROM dbo.tbl_DataType_A a
	INNER JOIN dbo.tbl_DataType_B b
	ON b.Field_B = a.Field_A
WHERE a.Field_A < @MyUpperLimit;

--
-- Bonus situation: Not all conversions will proceed as expected either
--
DECLARE @MyVarChar VARCHAR(20) = '9876543210';
SELECT CASE WHEN @MyVarChar = 0 THEN 'Match' ELSE 'No Match' END;