﻿/*
Assertions: A, B, C, D, E, F, G, H, I, J, K, L

Rule 1: (A AND B AND C) OR (A AND B AND D)
Rule 2: (E OR F OR G) AND (NOT (H AND I))
Rule 3: J AND (E OR F OR G OR (A AND B AND C))
*/

DECLARE @Assertion TABLE (AssertionID INT, AssertionName VARCHAR(16));
INSERT INTO @Assertion (AssertionID, AssertionName)
VALUES	(1,'A'),(2,'B'),(3,'C'),(4,'D'),(5,'E'),(6,'F'),(7,'G'),(8,'H'),(9,'I'),(10,'J');

DECLARE @Rule TABLE (RuleID INT, ParentRuleID INT, LogicalID TINYINT);
INSERT INTO @Rule (RuleID, ParentRuleID, LogicalID)
VALUES	(1, NULL, 2), (4, 1, 1), (5, 1, 1),
		(2, NULL, 1), (6, 2, 2), (7, 2, 3), (8, 7, 1),
		(3, NULL, 1), (9, 3, 2), (10, 9, 1);

DECLARE @RuleAssertion TABLE (RuleAssertionID INT, RuleID INT, AssertionID INT);
INSERT INTO @RuleAssertion (RuleAssertionID, RuleID, AssertionID)
VALUES	(1, 3, 10), (2, 3, 11), (3, 3, 12), (4, 4, 1), (5, 4, 2), (6, 4, 3), (7, 5, 1), (8, 5, 2), (9, 5, 4),
		(10, 6, 5), (11, 6, 6), (12, 6, 7), (13, 8, 8), (14, 8, 9),
		(15, 3, 10), (16, 9, 5), (17, 9, 6), (18, 9, 7), (19, 10, 1), (20, 10, 2), (21, 10, 3);

DECLARE @AssertionValue TABLE (AssertionValueID INT, ResultSetID INT, AssertionID INT, AssertionValue TINYINT);
INSERT INTO @AssertionValue (AssertionValueID, ResultSetID, AssertionID, AssertionValue)
VALUES	(1, 1, 1, 1), (2, 1, 2, 1), (3, 1, 3, 1), (4, 1, 4, 0), (5, 1, 5, 1), (6, 1, 6, 0), (7, 1, 7, 0), (8, 1, 8, 1), (9, 1, 9, 0), (10, 1, 10, 1),
		(11, 2, 1, 1), (12, 2, 2, 0), (13, 2, 3, 0), (14, 2, 4, 1), (15, 2, 5, 1), (16, 2, 6, 0), (17, 2, 7, 0), (18, 2, 8, 1), (19, 2, 9, 1), (20, 2, 10, 0),
		(21, 3, 1, 0), (22, 3, 2, 1), (23, 3, 3, 1), (24, 3, 4, 1), (25, 3, 5, 1), (26, 3, 6, 1), (27, 3, 7, 1), (28, 3, 8, 0), (29, 3, 9, 1), (30, 3, 10, 1);


DECLARE @RowCnt bigint,
		@LevelCnt int = 0;

DECLARE @RuleTree TABLE (TopRuleID INT, ParentRuleID INT, RuleID INT, LogicalID TINYINT, LevelCnt INT);
DECLARE @RuleResult TABLE (ParentRuleID INT, RuleID INT, ResultSetID INT, LevelCnt INT, ResultValue TINYINT);

-- Create Rule Tree - Level 0
INSERT INTO @RuleTree (TopRuleId, RuleId, LogicalID, LevelCnt)
SELECT	r.RuleId, r.RuleId, r.LogicalID, 0
FROM	@Rule r
WHERE	r.ParentRuleID IS NULL;

SET @RowCnt = @@ROWCOUNT;

-- Create Rule Tree - Level n
WHILE @RowCnt > 0 BEGIN
	SET @LevelCnt = @LevelCnt + 1;

	INSERT INTO @RuleTree (TopRuleId, ParentRuleId, RuleId, LogicalId, LevelCnt)
	SELECT	rt.TopRuleId, r.ParentRuleId, r.RuleId, r.LogicalId, @LevelCnt
	FROM	@RuleTree rt
	INNER JOIN @Rule r
		ON	r.ParentRuleId = rt.RuleId
	WHERE	rt.LevelCnt = @LevelCnt-1;

	SET @RowCnt = @@ROWCOUNT;
END

-- Collect Assertion Results
INSERT INTO @RuleResult(ParentRuleID, RuleID, ResultSetID, LevelCnt, ResultValue)
SELECT	rt.RuleID, NULL, av.ResultSetID, rt.LevelCnt+1, av.AssertionValue
FROM	@RuleTree rt
INNER JOIN @RuleAssertion ra
	ON	ra.RuleID = rt.RuleID
INNER JOIN @AssertionValue av
	ON	av.AssertionID = ra.AssertionID

-- Calculate Rule Results - Level n
WHILE @LevelCnt > 0 BEGIN
	SET @LevelCnt = @LevelCnt - 1;

	WITH cteLevelResult(ParentRuleID, RuleID, LogicalID, RuleSetID, LevelCnt, RecCount, RecTotal) AS (
		SELECT	rt.ParentRuleID, rt.RuleID, rt.LogicalID, rr.ResultSetID, rt.LevelCnt,
				COUNT(rr.ResultSetID) AS RecCount, SUM(rr.ResultValue) AS RecTotal
		FROM	@RuleTree rt
		INNER JOIN @RuleResult rr
			ON	rr.ParentRuleID = rt.RuleID
			AND rr.LevelCnt = rt.LevelCnt + 1
		WHERE	rt.LevelCnt = @LevelCnt
		GROUP BY rt.ParentRuleID, rt.RuleID, rt.LogicalID, rr.ResultSetID, rt.LevelCnt
		)
	INSERT INTO @RuleResult(ParentRuleID, RuleID, ResultSetID, LevelCnt, ResultValue)
	SELECT	ParentRuleID, RuleID, RuleSetID, LevelCnt,
			CASE WHEN   ((LogicalID = 1) AND (RecCount = RecTotal)) OR			-- AND
						((LogicalID = 2) AND (RecTotal > 0)) OR					-- OR
						((LogicalID = 3) AND (RecTotal = 0)) THEN 1 ELSE 0 END	-- NOT
	FROM cteLevelResult;
END


SELECT	rr.ResultSetID, rr.RuleID, CASE WHEN rr.ResultValue = 1 THEN 'True' ELSE 'False' END AS FinalResult
FROM	@RuleResult rr
INNER JOIN @Rule r
	ON	r.RuleID = rr.RuleID
	AND r.ParentRuleID IS NULL
ORDER BY rr.ResultSetID, rr.RuleID;