--
-- Create
--
CREATE PROCEDURE dbo.Item_Insert (
			@Name NVARCHAR(100),
			@Description NVARCHAR(250),
			@ParentID INT = NULL,
			@CreatedBy INT,
			@ID INT OUTPUT
			)
AS BEGIN
	SET NOCOUNT ON;

	INSERT INTO dbo.Items(Name, Description, ParentID, IsActive, CreatedBy, CreatedOn, ModifiedBy, ModifiedOn)
	VALUES (@Name, @Description, @ParentID, 1, @CreatedBy, GETDATE(), @CreatedBy, GETDATE());

	SET @ID = SCOPE_IDENTITY();
END

--
-- Read
--
CREATE PROCEDURE dbo.Item_Select
AS BEGIN
	SET NOCOUNT ON;

	SELECT	d.ID, d.Name, d.Description, d.ParentID, d.IsActive, d.CreatedBy, d.CreatedOn, d.ModifiedBy, d.ModifiedOn, p.Name AS ParentItemName
	FROM	dbo.Items d
	LEFT JOIN dbo.Items p
		ON	p.ID = d.ParentID
	WHERE	d.IsActive = 1
	ORDER BY d.Name;
END

--
-- Read by ID
--
CREATE PROCEDURE dbo.Items_SelectBy_ID (@ID INT)
AS BEGIN
	SET NOCOUNT ON;

	SELECT	d.ID, d.Name, d.Description, d.ParentID, d.IsActive, d.CreatedBy, d.CreatedOn, d.ModifiedBy, d.ModifiedOn, p.Name AS ParentItemName
	FROM	dbo.Items d
	LEFT JOIN dbo.Items p
		ON	p.ID = d.ParentID
	WHERE	d.IsActive = 1
		AND d.ID = @ID;
END

--
-- Read by Name
--
CREATE PROCEDURE dbo.Items_SelectBy_Name (@Name NVARCHAR(100))
AS BEGIN
	SET NOCOUNT ON;

	SELECT	d.ID, d.Name, d.Description, d.ParentID, d.IsActive, d.CreatedBy, d.CreatedOn, d.ModifiedBy, d.ModifiedOn, p.Name AS ParentItemName
	FROM	dbo.Items d
	LEFT JOIN dbo.Items p
		ON	p.ID = d.ParentID
	WHERE	d.IsActive = 1
		AND d.Name = @Name;
END

--
-- Read by Name Part
--
CREATE PROCEDURE dbo.Items_SelectBy_NamePart (@NamePart NVARCHAR(100))
AS BEGIN
	SET NOCOUNT ON;

	SELECT	d.ID, d.Name, d.Description, d.ParentID, d.IsActive, d.CreatedBy, d.CreatedOn, d.ModifiedBy, d.ModifiedOn, p.Name AS ParentItemName
	FROM	dbo.Items d
	LEFT JOIN dbo.Items p
		ON	p.ID = d.ParentID
	WHERE	d.IsActive = 1
		AND d.Name LIKE @NamePart
	ORDER BY d.Name;
END

--
-- Update by ID
--
CREATE PROCEDURE dbo.Items_Update (
			@ID INT,
			@Name NVARCHAR(100),
			@Description NVARCHAR(250),
			@ModifiedBy  INT
			)
AS BEGIN
	SET NOCOUNT ON;

	IF EXISTS ( SELECT	1
				FROM	dbo.Items
				WHERE	ID = @ID
					AND IsActive = 0) BEGIN
		RAISERROR(50021,11,1,'Unknown Item');
		RETURN;
	END

	UPDATE	dbo.Items
		SET	Name = @Name,
			Description = @Description,
			ModifiedBy = @ModifiedBy
	WHERE	ID = @ID
		AND IsActive = 1;
END

--
-- Delete by ID
--
CREATE PROCEDURE dbo.Items_Delete (@ID INT, @ModifiedBy INT)
AS BEGIN
	SET NOCOUNT ON;

	UPDATE	dbo.Items
		SET IsActive = 0,
			ModifiedBy = @ModifiedBy,
			ParentID = NULL
	WHERE	ID = @ID
		AND IsActive = 1;
END

--
-- Delete Multiple by ID (I'm not making this up!!)
--
CREATE PROCEDURE dbo.Items_Delete_Multiple (@ID_List NVARCHAR(MAX), @ModifiedBy INT)
AS BEGIN
	SET NOCOUNT ON;

	DECLARE @ID INT,
			@CurrentPos INT,
			@NextPos INT,
			@ErrorCode INT;

    SET @CurrentPos = 1;

    WHILE (@CurrentPos <= LEN(@ID_List)) BEGIN
        SET @NextPos = CHARINDEX(N',', @ID_List,  @CurrentPos);
        IF (@NextPos = 0 OR @NextPos IS NULL)
            SELECT @NextPos = LEN(@ID_List) + 1;

        SET @ID = CAST(SUBSTRING(@ID_List, @CurrentPos, @NextPos - @CurrentPos) AS INT);
        SET @CurrentPos = @NextPos + 1;

        IF (@ID > 0) BEGIN
            EXEC dbo.Items_Delete @ID, @ModifiedBy;
			SET @ErrorCode = @@ERROR;
            IF (@ErrorCode <> 0) BEGIN
                SET @ErrorCode = -1
                GOTO Cleanup
            END
        END
    END
    RETURN 0

Cleanup:
    RETURN @ErrorCode
END

--
-- Delete Multiple as it should be
--
CREATE PROCEDURE dbo.Items_Delete (@ID_List NVARCHAR(MAX), @ModifiedBy INT)
AS BEGIN
	SET NOCOUNT ON;

	UPDATE	i
		SET IsActive = 0,
			ModifiedBy = @ModifiedBy,
			ParentID = NULL
	FROM	dbo.Items AS i
	INNER JOIN dbo.tfGetIntegerList(@ID_List) AS gil -- Inline Table-Valued Function to split string and return integer values
		ON	gil.ID = i.ID
	WHERE	IsActive = 1;
END
