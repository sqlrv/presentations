--
-- Previous Multi-Statement Table-Valued Function
--
CREATE FUNCTION dbo.Items_ManagedBy_UserID (@UserID INT)
RETURNS @ManagedIDs TABLE (ID INT PRIMARY KEY)
AS BEGIN
	IF EXISTS ( SELECT	1
				FROM	dbo.Users
				WHERE	ID = @UserID
					AND IsAdmin = 1
					AND IsActive = 1) BEGIN
		INSERT INTO @ManagedIDs
		SELECT	i.ID
		FROM	dbo.Items AS i
		WHERE	i.IsActive = 1;
	END
	ELSE BEGIN
		INSERT INTO @ManagedIDs
		SELECT DISTINCT i.ID
		FROM	dbo.Items AS i
		WHERE	i.IsActive = 1
			AND i.ItemID IN (SELECT	ItemID
							 FROM	dbo.User_Select_WorkspaceItems(@UserID, @DomainID, 0, 16)) -- Multi-Statement Table-Valued Function
				OR i.CreatedBy = @UserID;
	END

	RETURN;
END

--
-- Replacement Inline Table-Valued Function
--
CREATE FUNCTION dbo.Items_ManagedBy_UserID(@UserID INT)
RETURNS TABLE WITH SCHEMABINDING
AS RETURN
	SELECT	i.ID
	FROM	dbo.Items AS i
	WHERE	i.IsActive = 1
		AND EXISTS (SELECT 1 FROM dbo.Users WHERE ID = @UserID AND IsActive = 1 AND IsAdmin = 1)
	UNION
	SELECT	i.ID
	FROM	dbo.Items AS i
	INNER JOIN dbo.User_Select_WorkspaceItems(@UserID, 1, 0, 16) uswsi -- Inline Table-Valued Function
		ON uswsi.ItemID = fi.ItemID
	WHERE	i.IsActive = 1
		AND EXISTS (SELECT 1 FROM dbo.Users WHERE ID = @UserID AND IsActive = 1 AND IsAdmin = 0)
	UNION
	SELECT	i.ID
	FROM	dbo.Items AS i
	WHERE	i.IsActive = 1
		AND i.CreatedBy = @UserID;
GO
