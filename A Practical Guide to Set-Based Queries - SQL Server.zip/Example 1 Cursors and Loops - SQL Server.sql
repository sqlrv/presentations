--
-- Initial procedure with two cursors
--
CREATE PROCEDURE dbo.Cleanup_Inactive_Patients(@PatientTableName NVARCHAR(255), @OverviewTableName NVARCHAR(255))
AS BEGIN
	DECLARE @createdOn DATETIME,
			@matrixRowsReturned INT,
			@ID INT, 
			@ID_PatientName NVARCHAR(255), 
			@ID_PatientID INT,
			@ID_Active_Status_Name NVARCHAR(255),
			@ID_Active_Status_Name_p NVARCHAR(255),
			@ID_Active_Status_Name_o NVARCHAR(255), 
			@ID_Disease_Name NVARCHAR(255),
			@ID_LastExposure DATETIME,
			@inactiveID INT

	--get list item id for inactive
	SELECT	@inactiveID = li.ID
	FROM	dbo.ListItems AS li
	INNER JOIN dbo.Lists AS l
		ON	l.id = li.listid
	INNER JOIN dbo.Measures AS m
		ON	m.listid = l.id
	WHERE	m.name = 'ID_Active_Status'
		AND li.isactive = 1
		AND li.name = 'Inactive';

	--
	--get Data that will be used to get user ids to send notification too.
	--
	DECLARE @ActivePatientsTBL TABLE (
			ID INT,
			ID_PatientName NVARCHAR(255),
			ID_Active_Status_Name NVARCHAR(255),
			ID_Disease_Name NVARCHAR(255),
			ID_LastExposure DATETIME
			);
	DECLARE @sqlstmt NVARCHAR(MAX);
		
	SET @sqlstmt = '
		SELECT	m.ID,
				m.ID_PatientName,
				m.ID_Active_Status_Name,
				m.ID_Disease_Name,
				m.ID_LastExposure
		FROM	dbo.' + @PatientTableName + ' AS m
		WHERE	m.IsActive = 1
			AND m.ID_Active_Status_Name = ''Active''	
			AND m.ID_LastExposure IS NOT NULL';

	--full table
	INSERT INTO @ActivePatientsTBL
	EXEC(@sqlstmt);

	--
	--create cursor loop for each patient matching criteria
	--

	DECLARE patientCursor CURSOR FOR 
		SELECT	ID,
				ID_PatientName,
				ID_Active_Status_Name,
				ID_Disease_Name,
				ID_LastExposure				  			
		FROM	@ActivePatientsTBL;

	OPEN patientCursor;
	FETCH NEXT FROM patientCursor INTO @ID, @ID_PatientName, @ID_Active_Status_Name, @ID_Disease_Name, @ID_LastExposure
	WHILE @@FETCH_STATUS = 0 BEGIN
		DECLARE @DiseaseDays INT;

		SELECT	@DiseaseDays = d.MonitorDays
		FROM	@DiseasesTBL AS d
		WHERE	d.Name = @ID_Disease_Name;

		SET @diseaseDays = @diseaseDays + 1;

		IF @ID_LastExposure <= DATEADD(dd, -@diseaseDays, GETDATE()) BEGIN
			SET @sqlstmt = '
				UPDATE	' + @PatientTableName + '
					SET ID_Active_Status = ' + CONVERT(VARCHAR(20), @inactiveID) + ',
						ModifiedBy = 1,
						ModifiedOn = GETDATE()
				WHERE	ID = ' + CONVERT(VARCHAR(20), @ID) + '
					AND IsActive = 1;

				UPDATE	' + @OverviewTableName + '
					SET ID_Active_Status = ' + CONVERT(VARCHAR(20), @inactiveID) + ',
						ModifiedBy = 1,
						ModifiedOn = GETDATE()
				WHERE	ID_PatientID = ' + CONVERT(VARCHAR(20), @ID) + '
					AND IsActive = 1;'	
			EXEC(@sqlstmt)
		END
		FETCH NEXT FROM patientCursor INTO @ID, @ID_PatientName, @ID_Active_Status_Name, @ID_Disease_Name, @ID_LastExposure;
	END

	CLOSE patientCursor;
	DEALLOCATE patientCursor;
		
	--
	-- finds patients that have been turned inactive manaully and changes the overview to be inactive as well. 
	--
	DECLARE @ManualInactiveTBL TABLE (
			ID INT,
			ID_PatientID INT,
			ID_PatientName NVARCHAR(255),
			ID_Active_Status_Name_p	NVARCHAR(255),
			ID_Active_Status_Name_o	NVARCHAR(255),
			ID_Disease_Name NVARCHAR(255),
			ID_LastExposure DATETIME
			);

	SET @sqlstmt = '
			SELECT	m.ID,
					o.ID_PatientID,
					m.ID_PatientName,
					m.ID_Active_Status_Name AS ID_Active_Status_Name_p,
					o.ID_Active_Status_Name AS ID_Active_Status_Name_o,
					m.ID_Disease_Name,
					m.ID_LastExposure
			FROM	dbo.' + @PatientTableName + ' AS m
			INNER JOIN dbo. ' + @OverviewTableName + ' AS o
				ON	o.ID_PatientID = m.ID
			WHERE	m.IsActive = 1
				AND o.ID_Active_Status_Name = ''Active''	
				AND m.ID_Active_Status_Name != o.ID_Active_Status_Name;'

	--full table
	INSERT INTO @ManualInactiveTBL
	EXEC(@sqlstmt)

	DECLARE patientCursor CURSOR FOR 
		SELECT	ID,
				ID_PatientID,
				ID_PatientName,
				ID_Active_Status_Name_p,
				ID_Active_Status_Name_o,
				ID_Disease_Name,
				ID_LastExposure
		FROM	@ManualInactiveTBL;

	OPEN patientCursor;
	FETCH NEXT FROM patientCursor INTO @ID, @ID_PatientID, @ID_PatientName, @ID_Active_Status_Name_p, @ID_Active_Status_Name_o, @ID_Disease_Name, @ID_LastExposure;
	WHILE @@FETCH_STATUS = 0 BEGIN
		SET	@sqlstmt = '
			UPDATE	' + @OverviewTableName + '
				SET ID_Active_Status = ' + CONVERT(VARCHAR(20), @inactiveID) + ',
					ModifiedBy = 1,
					ModifiedOn = GETDATE()
			WHERE	ID_PatientID = ' + CONVERT(VARCHAR(20), @ID) + '
				AND IsActive = 1;'	
		EXEC(@sqlstmt);
		FETCH NEXT FROM patientCursor INTO @ID, @ID_PatientID, @ID_PatientName, @ID_Active_Status_Name_p, @ID_Active_Status_Name_o, @ID_Disease_Name, @ID_LastExposure;
	END

	CLOSE patientCursor;
	DEALLOCATE patientCursor;
END

--
-- Procedure where cursors are eliminated
--
CREATE PROCEDURE dbo.Cleanup_Inactive_Patients(@PatientTableName NVARCHAR(255), @OverviewTableName NVARCHAR(255))
AS BEGIN
	SET NOCOUNT ON;
	DECLARE @inactiveID INT,
			@sqlstmt NVARCHAR(MAX);

	-- get list item id for inactive
	SELECT	@inactiveID = li.ID 
	FROM	dbo.ListItems AS li
	INNER JOIN lists AS l
		ON	l.ID = li.ListID
	INNER JOIN dbo.Measures AS m
		ON	m.ListID = l.ID
	WHERE	m.Name = N'ID_Active_Status'
		AND li.IsActive = 1
		AND li.Name = N'Inactive';

	--
	-- get matrixView Data that will be used to get user ids to send notification too.
	--
	CREATE TABLE #ActivePatients (
			ID INT
			);
		
	SET @sqlstmt = N'
		INSERT INTO #ActivePatients
		SELECT	m.ID
		FROM	dbo.' + @PatientTableName + N' as m
		INNER JOIN dbo.Diseases d
			ON	d.Name = m.ID_Disease_Name
			AND m.ID_LastExposure <= DATEADD(dd, -(d.MonitorDays + 1), GETDATE())
		WHERE	m.IsActive = 1
			AND m.ID_Active_Status_Name = ''Active''
			AND m.ID_LastExposure IS NOT NULL;';

	EXECUTE sp_executesql @sqlstmt;

	SET @sqlstmt = N'
	UPDATE	ptn
		SET ID_Active_Status = CONVERT(VARCHAR(20), @inactiveID),
			ModifiedBy = 1,
			ModifiedOn = GETDATE()
	FROM	dbo.' + @PatientTableName + N' ptn
	INNER JOIN #ActivePatients ap
		ON	ap.ID = ptn.ID
	WHERE	ptn.IsActive = 1;

	UPDATE	otn
		SET ID_Active_Status = CONVERT(VARCHAR(20), @inactiveID),
			ModifiedBy = 1,
			ModifiedOn = GETDATE()
	FROM	dbo.' + @OverviewTableName + N' otn
	INNER JOIN #ActivePatients ap
		ON	ap.ID = otn.ID_PatientID
	WHERE	otn.IsActive = 1;'	;

	EXECUTE sp_executesql @sqlstmt, N'@inactiveID INT', @inactiveID = @inactiveID;
				
	SET @sqlstmt = N'
	UPDATE	otn
		SET ID_Active_Status = @inactiveID,
			ModifiedBy = 1,
			ModifiedOn = GETDATE()
	FROM	dbo.' + @OverviewTableName + N' otn
	INNER JOIN dbo.' + @PatientTableName + N' AS m
		ON	m.ID = otn.ID_PatientID
		AND m.ID_Active_Status_Name <> otn.ID_Active_Status_Name
	WHERE otn.IsActive = 1;';

	EXECUTE sp_executesql @sqlstmt, N'@inactiveID INT', @inactiveID = @inactiveID;
END
