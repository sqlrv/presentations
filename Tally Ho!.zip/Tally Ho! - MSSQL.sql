USE Scratch;

/*
 *	How it works:
 */
-- Data Rows
	SELECT	StringValue
	FROM	(VALUES('One'),('Two'),('Three'),('Four'),('Five')) AS s(StringValue);

-- Tally table Rows
	SELECT	n
	FROM	(VALUES(1),(2),(3),(4),(5),(6),(7),(8),(9),(10)) AS t(n);

-- Data Rows cross joined with tally table rows
	SELECT	n, StringValue
	FROM	(VALUES('One'),('Two'),('Three'),('Four'),('Five')) AS s(StringValue)
	CROSS APPLY (VALUES(1),(2),(3),(4),(5),(6),(7),(8),(9),(10)) AS t(n);

-- Limit results to where n is the number of characters in the string
	SELECT	n, StringValue
	FROM	(VALUES('One'),('Two'),('Three'),('Four'),('Five')) AS s(StringValue)
	CROSS APPLY (VALUES(1),(2),(3),(4),(5),(6),(7),(8),(9),(10)) AS t(n)
	WHERE	n <= LEN(StringValue);

-- Making use of tally rows to "loop" through strings and highlight each letter
	SELECT	n,  CASE WHEN n=1 THEN '' ELSE LEFT(StringValue, n-1) END + '>' +
				SUBSTRING(StringValue, n, 1) + '<' +
				CASE WHEN n=LEN(StringValue) THEN '' ELSE SUBSTRING(StringValue, n+1, 8000) END AS StringValue
	FROM	(VALUES('One'),('Two'),('Three'),('Four'),('Five')) AS s(StringValue)
	CROSS APPLY (VALUES(1),(2),(3),(4),(5),(6),(7),(8),(9),(10)) AS t(n)
	WHERE	n <= LEN(StringValue);

-- How exponential growth is utilized (no need to run)
/*
	WITH e1(n) AS (SELECT n FROM (VALUES (1),(1),(1),(1),(1),(1),(1),(1),(1),(1),(1),(1),(1),(1),(1),(1)) AS x(n)) -- 16 records
		,e2(n) AS (SELECT 1 FROM e1 a CROSS JOIN e1 b) -- 16^2 or 256 records (16*16)
		,e4(n) AS (SELECT 1 FROM e2 a CROSS JOIN e2 b) -- 16^4 or 65,536 records (256*256)
		,e8(n) AS (SELECT 1 FROM e4 a CROSS JOIN e4 b) -- 16^8 or 4,294,967,296 records (65,536*65,536)
	SELECT n FROM e8;
*/

--
----------------------------------------------------------------------------------------------------------------------------------------
--

/*
 *	Create as a table function utilizing increasing exponential growth
 *	Advantage is that this is in memory only with no disk I/O required
 */
	IF OBJECT_ID(N'dbo.fnTally', N'IF') IS NOT NULL DROP FUNCTION dbo.fnTally;
	GO
	/*
	 * Function: fnTally
	 *     Returns a table of sequence values based on the parameters
	 * Parameters:
	 *     @RowCnt    : The number of rows to be generated 
	 *     @ZeroOrOne : Indicate the starting value of either 0 or 1
	 */
	CREATE OR ALTER FUNCTION dbo.fnTally(@RowCnt bigint, @ZeroOrOne bit = 1)
	RETURNS TABLE WITH SCHEMABINDING
	AS RETURN
		WITH e1(n) AS (SELECT n FROM (VALUES (1),(1),(1),(1),(1),(1),(1),(1),(1),(1),(1),(1),(1),(1),(1),(1)) AS x(n)) -- 16 records
			,e4(n) AS (SELECT 1 FROM e1 a CROSS JOIN e1 b CROSS JOIN e1 c CROSS JOIN e1 d) -- 16^4 or 65,536 records (256*256)
			,e8(n) AS (SELECT 1 FROM e4 a CROSS JOIN e4 b) -- 16^8 or 4,294,967,296 records (65,536*65,536)
		SELECT	TOP (@RowCnt) ROW_NUMBER() OVER (ORDER BY (SELECT 1)) - (CAST(~@ZeroOrOne AS BIGINT)) AS n
		FROM	e8;
	GO

/*
 *	Create as a fixed table utilizing increasing exponential growth
 */
-- Create a fixed Tally table
	DROP TABLE IF EXISTS dbo.Tally;
	CREATE TABLE dbo.Tally (n INT NOT NULL PRIMARY KEY CLUSTERED);

-- Populate the Tally table
	WITH e1(n) AS (SELECT n FROM (VALUES (1),(1),(1),(1),(1),(1),(1),(1),(1),(1),(1),(1),(1),(1),(1),(1)) AS x(n)) -- 16 records
		,e4(n) AS (SELECT 1 FROM e1 a CROSS JOIN e1 b CROSS JOIN e1 c CROSS JOIN e1 d) -- 16^4 or 65,536 records (256*256)
	INSERT	INTO dbo.Tally(n)
	SELECT	ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS n
	FROM	e4;
	GRANT SELECT, REFERENCES ON dbo.Tally TO PUBLIC;
	GO

--
----------------------------------------------------------------------------------------------------------------------------------------
--

/*
 *	Example 1:	I want to find out how many people have a birthday in each month but I don't want to
 *				skip any months.
 */

-- Let's populate a table with our data
	DROP TABLE IF EXISTS #PersonList;
	CREATE TABLE #PersonList (
				PersonID int,
				FirstName varchar(32),
				LastName varchar(32),
				DOB date
				);
	INSERT INTO #PersonList (PersonID, FirstName, LastName, DOB)
	VALUES	(123456, 'Duck', 'Daffy', '03/05/1964'),
			(234567, 'Bunny', 'Bugs', '02/29/1964'),
			(345678, 'Coyote', 'Wile', '01/15/1966'),
			(456789, 'Runner', 'Road', '04/23/1974'),
			(567890, 'Duck', 'Daisy', '05/03/1966'),
			(564231, 'Fudd', 'Elmer', '03/20/1946'),
			(853156, 'Bird', 'Tweety', '10/10/1960'),
			(462137, 'Cat', 'Sylvester', '12/15/1955'),
			(134679, 'LePue', 'Peppy', '11/11/1959'),
			(963741, 'Duck', 'Huey', '09/09/1979'),
			(963742, 'Duck', 'Louie', '09/09/1979'),
			(963743, 'Duck', 'Dewey', '09/09/1979');


-- Normally I'd use this query
	SELECT	DATEPART(mm, DOB) as 'Month', COUNT(*) AS [Count]
	FROM	#PersonList
	GROUP BY DATEPART(mm, DOB);

-- However, this will not return a row for any month that did not have a birthday.  You can use a
-- tally to ensure that you have totals for all 12 months, even for months without a birthday.
	SELECT	t.n AS 'Month', COUNT(DATEPART(mm, pl.DOB)) AS [Count]
	FROM 	dbo.fnTally(12,1) t
	LEFT JOIN #PersonList pl
		ON 	t.n = DATEPART(mm, pl.DOB)
	GROUP BY t.n;
	GO

--
----------------------------------------------------------------------------------------------------------------------------------------
--

/*
 *	Example 2:	Let's say that you need to generate a list of all dates for the third milennium
 *				inclusive. You might use a temp table or table variable, and construct a loop that
 *				inserts records for each date in the range. By using a tally table, all you need is
 *				this (using variables to make it flexible):
 */
	DECLARE @StartDate DATE = '01-Jan-2000',
			@EndDate DATE = '31-Dec-2999';

	WITH cteDateValue(TheDate) AS (
			SELECT	DATEADD(DAY, n, @StartDate) AS TheDate
			FROM 	dbo.fnTally(DATEDIFF(DAY, @StartDate, @EndDate), 0)
			)
	SELECT	TheDate AS [Date],
			DATENAME(WEEKDAY, TheDate) AS [DayName],
			DAY(TheDate) AS [DayOfMonth],
			DATEPART(DAYOFYEAR, TheDate) AS [DayOfYear],
			CASE WHEN DATEPART(WEEKDAY, TheDate) IN (CASE @@DATEFIRST WHEN 1 THEN 6 WHEN 7 THEN 1 END,7) THEN 1 ELSE 0 END AS [IsWeekend],
			DATEPART(WEEK, TheDate) AS [Week],
			MONTH(TheDate) AS [Month],
			DATENAME(MONTH, TheDate) AS [MonthName],
			DATEPART(QUARTER, TheDate) AS [Quarter],
			YEAR(TheDate) AS [Year]
	FROM	cteDateValue;
	GO

--
----------------------------------------------------------------------------------------------------------------------------------------
--

/*
 *	Example 3:	Break strings into multiple segments of a given length or less.
 */
	WITH cteString(StringValue, MaxLen) AS (
		SELECT 	StringValue, MaxLen
		FROM 	(VALUES('January,February,March,April,May,June,July,August,September,October,November,December', 10)) AS x(StringValue, MaxLen)
		)
	SELECT 	t.n AS SegmentNbr, SUBSTRING(s.StringValue, (t.n * s.MaxLen)+1, s.MaxLen) AS SegmentStr
	FROM 	cteString s
	CROSS APPLY dbo.fnTally(10, 0) AS t
	WHERE 	LEN(s.StringValue)-(t.n * s.MaxLen) > 0
	ORDER BY t.n;
	GO

--
----------------------------------------------------------------------------------------------------------------------------------------
--

/*
 *	Example 4:	Break strings according to delimiter
 */
--
-- Most string split UDF functions are created like this:
--
	/*
	 * Function: udfSplitString
	 *     Returns a table of string segments based upon the given delimiter
	 * Parameters:
	 *     @StringValue : The string value to be split
	 *     @Delimiter   : The delimiter to be used in splitting the string
	 */
	CREATE OR ALTER FUNCTION dbo.udfSplitString (@StringValue VARCHAR(8000), @Delimiter VARCHAR(1))
		RETURNS @SplitString TABLE(SegmentNbr INT, SegmentStr VARCHAR(8000))
	AS BEGIN
		DECLARE	@StrLen INT = LEN(@StringValue),	--Length of string
				@StartAt INT = 1,					--Position to begin search for delimeter
				@StrPos INT = 1,					--Position where delimeter was found
				@SegNbr INT = 0;					--Segment sequence

		WHILE @StartAt <= @StrLen BEGIN
			SET @StrPos = CHARINDEX(@Delimiter, @StringValue, @StartAt);
			SET @SegNbr += 1;
			IF @StrPos = 0 BEGIN
				INSERT @SplitString(SegmentNbr, SegmentStr)
					SELECT @SegNbr, LTRIM(RTRIM(SUBSTRING(@StringValue , @StartAt, 1 + @StrLen - @StartAt)));
				SET @StartAt = @StrLen + 1
				END
			ELSE BEGIN
				INSERT @SplitString(SegmentNbr, SegmentStr)
					SELECT @SegNbr, LTRIM(RTRIM(SUBSTRING(@StringValue, @StartAt, @StrPos - @StartAt)));
				SET @StartAt = @StrPos + 1;
				END
			END
		RETURN;
	END
	GO

--
-- Many solutions use recursive CTE solutions like this:
--
	/*
	 * Function: tvfSplitString
	 *     Returns a table of string segments based upon the given delimiter
	 * Parameters:
	 *     @StringValue : The string value to be split
	 *     @Delimiter   : The delimiter to be used in splitting the string
	 */
	CREATE OR ALTER FUNCTION dbo.tvfSplitString(@StringValue VARCHAR(8000), @Delimiter VARCHAR(1))
	RETURNS TABLE WITH SCHEMABINDING
	AS RETURN
		WITH e1(n) AS (SELECT n FROM (VALUES (1),(1),(1),(1),(1),(1),(1),(1),(1),(1),(1),(1),(1),(1),(1),(1)) AS x(n)), -- 16 records
		cteTally(n) AS (
			SELECT 	TOP(ISNULL(LEN(@StringValue),0)) ROW_NUMBER() OVER (ORDER BY (SELECT 1))
			FROM 	e1 a CROSS JOIN e1 b CROSS JOIN e1 c CROSS JOIN (VALUES (1),(1)) AS d(n) -- 16^3 * 2 or 8192 records
			),
		cteStartPos(StartPos) AS (
			SELECT 	1
			UNION ALL
			SELECT 	n+1
			FROM 	cteTally AS t
			WHERE 	SUBSTRING(@StringValue, n, 1) = @Delimiter
				AND t.n <= LEN(@StringValue)
			),
		cteSegmentLen(StartPos, StringLen) AS (
			SELECT 	StartPos, ISNULL(NULLIF(CHARINDEX(@Delimiter, @StringValue, StartPos), 0) - StartPos, (LEN(@StringValue)-StartPos)+1)
			FROM 	cteStartPos
			)
		SELECT	ROW_NUMBER() OVER (ORDER BY StartPos) AS SegmentNbr,
				SUBSTRING(@StringValue, StartPos, StringLen) AS SegmentStr
		FROM 	cteSegmentLen;
	GO

--
-- Create as a generic Inline Table-Value Function
-- v2016 now has built-in function: STRING_SPLIT ( string , separator )
--

--
-- This solution uses window functions to avoid the recursive CTE:
--
-- Be aware that the new STRING_SPLIT() function has several problems (Thanks to Jeff Moden):
--
-- 1. If you pass it a NULL, it returns no rows... not even a NULL.  This is atypical behavior for most string functions.
-- 2. The function does not return the ordinal position of the element being split out.  That also means...
-- 3. There is no guarantee of sort order.
	/*
	 * Function: fnSplitString
	 *     Returns a table of string segments based upon the given delimiter
	 * Parameters:
	 *     @StringValue : The string value to be split
	 *     @Delimiter   : The delimiter to be used in splitting the string
	 */
	CREATE OR ALTER FUNCTION dbo.fnSplitString(@StringValue VARCHAR(8000), @Delimiter VARCHAR(1))
	RETURNS TABLE WITH SCHEMABINDING
	AS RETURN
		WITH e1(n) AS (SELECT n FROM (VALUES (1),(1),(1),(1),(1),(1),(1),(1),(1),(1),(1),(1),(1),(1),(1),(1)) AS x(n)), -- 16 records
		cteTally(n) AS (
			SELECT 	TOP(ISNULL(LEN(@StringValue),0)) ROW_NUMBER() OVER (ORDER BY (SELECT 1)) - 1
			FROM 	e1 a CROSS JOIN e1 b CROSS JOIN e1 c CROSS JOIN (VALUES (1),(1)) AS d(n) -- 16^3 * 2 or 8192 records
			),
		cteDelim(pos) AS (
				SELECT	t.n
				FROM	cteTally t
				WHERE	(SUBSTRING(@StringValue, t.n, 1) LIKE @Delimiter) OR (t.n = 0)
				)
		SELECT	ROW_NUMBER() OVER (ORDER BY d.pos) AS SegmentNbr,
				SUBSTRING(@StringValue, d.pos + 1, LEAD(d.pos,1,LEN(@StringValue)+1) OVER (ORDER BY (SELECT NULL)) - d.pos - 1 ) AS SegmentStr
		FROM	cteDelim d;
		;
	GO

--
-- Use the procedural function
--
	SET STATISTICS IO, TIME ON;
	SELECT 	ss.SegmentNbr, ss.SegmentStr
	FROM 	dbo.udfSplitString('January,February,March,April,May,June,July,August,September,October,November,December', ',') AS ss
	ORDER BY ss.SegmentNbr;
	SET STATISTICS IO, TIME OFF;
	GO
--
-- Use the function based on tally with recursion
--
	SET STATISTICS IO, TIME ON;
	SELECT 	ss.SegmentNbr, ss.SegmentStr
	FROM 	dbo.tvfSplitString('January,February,March,April,May,June,July,August,September,October,November,December', ',') AS ss
	ORDER BY ss.SegmentNbr, ss.SegmentStr;
	SET STATISTICS IO, TIME OFF;
	GO
--
-- Use the function based on tally with window functions
--
	SET STATISTICS IO, TIME ON;
	SELECT 	ss.SegmentNbr, ss.SegmentStr
	FROM 	dbo.fnSplitString('January,February,March,April,May,June,July,August,September,October,November,December', ',') AS ss
	ORDER BY ss.SegmentNbr, ss.SegmentStr;
	SET STATISTICS IO, TIME OFF;
	GO

--
----------------------------------------------------------------------------------------------------------------------------------------
--

/*
 * Example 5:	Create test data
 */
	IF OBJECT_ID(N'tempdb..#TestData', N'U') IS NOT NULL DROP TABLE #TestData;
	CREATE TABLE #TestData(ID INT IDENTITY(1,1), DataString VARCHAR(50));

-- Usual method
-- This method performs a loop of 100 INSERT INTO statements
	INSERT INTO #TestData (DataString) VALUES (NEWID());
	GO 100

-- Tally method
-- This method performs a single INSERT INTO statement in set-based method
	TRUNCATE TABLE #TestData;
	INSERT 	INTO #TestData(DataString)
	SELECT 	NEWID()
	FROM 	dbo.fnTally(1000, 1);
	GO

--
----------------------------------------------------------------------------------------------------------------------------------------
--

/*
 * Example 6:	Generate Prime numbers up to 1000
 */
-- Typical procedural method
	SET STATISTICS IO, TIME ON;
    DECLARE @TopLimit INT = 1000,
			@i INT,
			@n INT = 0;
	DECLARE @PrimeList TABLE (n INT, isPrime BIT);

	WHILE @n < @TopLimit BEGIN
		SET @n += 1;
		INSERT INTO @PrimeList(n, isPrime)
		SELECT @n, 1;				-- Initially set all numbers as potential primes
	END

	SELECT @n = 2;					-- Start with the first known prime
	WHILE @n <= @TopLimit BEGIN
		SET @i = @n * @n;			-- Start with the square of the prime number
		WHILE @i <= @TopLimit BEGIN
			UPDATE	@PrimeList
				SET IsPrime = 0		-- Set multiples of the prime number as NOT prime
			WHERE	n = @i;
			SET @i += @n;			-- Increment by the prime number
		END
		SELECT	@n = MIN(n)			-- Go to the next known prime number
		FROM	@PrimeList
		WHERE	n > @n
			AND IsPrime = 1;
	END

	SELECT	n AS Prime
	FROM	@PrimeList
	WHERE	IsPrime = 1
	ORDER BY n;
	SET STATISTICS IO, TIME OFF;
	GO

-- Tally method (set-based)
	SET STATISTICS IO, TIME ON;
	SELECT	n AS Prime
	FROM	dbo.fnTally(1000, 1) AS N1
    WHERE NOT EXISTS (							-- Correlated sub-query
		SELECT	1
		FROM	dbo.fnTally(999, 1) AS N2
		WHERE	N2.n+1 < N1.n					-- We only need to test numbers less than the current number
			AND N1.n % (N2.n+1) = 0				-- Check to see if there are any numbers that evenly divide in
		)
	ORDER BY n;
	SET STATISTICS IO, TIME OFF;
	GO

--
----------------------------------------------------------------------------------------------------------------------------------------
--

/*
 * Advanced Functions:
 */

--
-- Let's test the new string split function by generating a random string of numeric values from 1 to 1000
--
	DECLARE @MyString NVARCHAR(MAX), @Delimiter NVARCHAR(1) = N',';
	SELECT	@MyString = STRING_AGG(CAST(ABS(CHECKSUM(NEWID())) % 1000 AS NVARCHAR(MAX)), @Delimiter)
	FROM	dbo.fnTally(1000,1);

	SELECT	@MyString AS DelimitedString;

	SELECT	*
	FROM	dbo.fnSplitString(@MyString, @Delimiter);
	GO
--
-- Self-contained date range generator:
--
	/*
	 * Function: fnDateRange
	 *     Returns a table of date values from the Start Date through the End Date
	 * Parameters:  
	 *     @StartDate : The date to start the sequence
	 *     @StopDate  : The date to end the sequence
	 */
	CREATE OR ALTER FUNCTION dbo.fnDateRange(@StartDate AS DATE, @StopDate AS DATE)
	RETURNS TABLE WITH SCHEMABINDING
	AS RETURN
		WITH e1(n) AS (SELECT n FROM (VALUES (1),(1),(1),(1),(1),(1),(1),(1),(1),(1),(1),(1),(1),(1),(1),(1)) AS x(n)) -- 16 records
			,e4(n) AS (SELECT 1 FROM e1 a CROSS JOIN e1 b CROSS JOIN e1 c CROSS JOIN e1 d) -- 16^4 or 65,536 records (256*256)
			,cteTally(n) AS (
				SELECT TOP(DATEDIFF(DAY, @StartDate, @StopDate)+1) ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS n
				FROM e4 a CROSS JOIN e4 b	-- 16^8 or 4,294,967,296 records (65,536*65,536)
				)
		SELECT DATEADD(DAY, n-1, @StartDate) AS DateVal
		FROM cteTally;
	GO

--
-- Let's test the Date Range function
--
	SELECT * FROM dbo.fnDateRange('12/1/2020','1/31/2021');
	GO
--
-- Create a more detailed Date/Time Range to include increments and date/time parts
--
	/*
	 * Function: fnDateTimeRange
	 *     Returns a table of datetime values based on the parameters
	 * Parameters:  
	 *     @StartDate : Start date of the series 
	 *     @EndDate   : End date of the series 
	 *     @DatePart  : The time unit for @interval
	 *         ns     : nanoseconds 
	 *         mcs    : microseconds 
	 *         ms     : milliseconds 
	 *         ss     : seconds
	 *         mi     : minutes
	 *         hh     : hours
	 *         dd     : days
	 *         ww     : weeks
	 *         mm     : months
	 *         qq     : quarters
	 *         yy     : years
	 *     @Interval  : The number of dateparts between each value returned
	 */
	CREATE OR ALTER FUNCTION dbo.fnDateTimeRange(@StartDate datetime2, @EndDate datetime2, @DatePart varchar(3)='dd', @Interval int=1)
	RETURNS TABLE WITH SCHEMABINDING
	AS RETURN
		WITH e1(n) AS (SELECT n FROM (VALUES (1),(1),(1),(1),(1),(1),(1),(1),(1),(1),(1),(1),(1),(1),(1),(1)) AS x(n)) -- 16 records
			,e4(n) AS (SELECT 1 FROM e1 a CROSS JOIN e1 b CROSS JOIN e1 c CROSS JOIN e1 d) -- 16^4 or 65,536 records (256*256)
			,cteTally(seqnbr, direction) AS (
				SELECT 	TOP(ABS(CASE @DatePart 	WHEN 'ns'  THEN DATEDIFF(ns, @EndDate, @StartDate)/@Interval
												WHEN 'mcs' THEN DATEDIFF(mcs,@EndDate, @StartDate)/@Interval
												WHEN 'ms'  THEN DATEDIFF(ms, @EndDate, @StartDate)/@Interval
												WHEN 'ss'  THEN DATEDIFF(ss, @EndDate, @StartDate)/@Interval
												WHEN 'mi'  THEN DATEDIFF(mi, @EndDate, @StartDate)/@Interval
												WHEN 'hh'  THEN DATEDIFF(hh, @EndDate, @StartDate)/@Interval
												WHEN 'dd'  THEN DATEDIFF(dd, @EndDate, @StartDate)/@Interval
												WHEN 'ww'  THEN DATEDIFF(ww, @EndDate, @StartDate)/@Interval
												WHEN 'mm'  THEN DATEDIFF(mm, @EndDate, @StartDate)/@Interval
												WHEN 'qq'  THEN DATEDIFF(qq, @EndDate, @StartDate)/@Interval
												WHEN 'yy'  THEN DATEDIFF(yy, @EndDate, @StartDate)/@Interval
												ELSE		 ABS(DATEDIFF(dd, @EndDate, @StartDate))/@Interval
												END) + 1)
						ROW_NUMBER() OVER (ORDER BY (SELECT 1)) - 1,
						CASE WHEN @StartDate < @EndDate THEN 1 ELSE -1 END
				FROM 	e4 a CROSS JOIN e4 b	-- 16^8 or 4,294,967,296 records (65,536*65,536)
				)
		SELECT 	CASE @DatePart 	WHEN 'ns'  THEN DATEADD(ns, direction * seqnbr * @Interval, @StartDate)
								WHEN 'mcs' THEN DATEADD(mcs,direction * seqnbr * @Interval, @StartDate)
								WHEN 'ms'  THEN DATEADD(ms, direction * seqnbr * @Interval, @StartDate)
								WHEN 'ss'  THEN DATEADD(ss, direction * seqnbr * @Interval, @StartDate)
								WHEN 'mi'  THEN DATEADD(mi, direction * seqnbr * @Interval, @StartDate)
								WHEN 'hh'  THEN DATEADD(hh, direction * seqnbr * @Interval, @StartDate)
								WHEN 'dd'  THEN DATEADD(dd, direction * seqnbr * @Interval, @StartDate)
								WHEN 'ww'  THEN DATEADD(ww, direction * seqnbr * @Interval, @StartDate)
								WHEN 'mm'  THEN DATEADD(mm, direction * seqnbr * @Interval, @StartDate)
								WHEN 'qq'  THEN DATEADD(qq, direction * seqnbr * @Interval, @StartDate)
								WHEN 'yy'  THEN DATEADD(yy, direction * seqnbr * @Interval, @StartDate)
								ELSE            DATEADD(dd, direction * seqnbr * @Interval, @StartDate)
								END AS DateTimeValue
		FROM 	cteTally;
	GO

--
-- Let's test the Date/Time Range function
--
	SELECT * FROM dbo.fnDateTimeRange('2021-01-01 00:00:00','2021-01-01 23:00:00', 'hh', 1);
	GO

--
-- A Tally function built like the PostgreSQL function generate_series.
--
	/*
	 * Function: fnGenerate_Series
	 *     Returns a table of sequence values based on the parameters up to the largest value of a bigint
	 * Parameters:  
	 *     @StartVal : The starting value
	 *     @StopVal  : The ending value
	 *     @StepVal  : The incremental value (can be negative as well)
	 */
	CREATE OR ALTER FUNCTION dbo.fnGenerate_Series(@StartVal bigint = 1, @StopVal bigint=0, @StepVal bigint = 1)
	RETURNS TABLE WITH SCHEMABINDING
	AS RETURN
		WITH e1(n) AS (SELECT n FROM (VALUES (1),(1),(1),(1),(1),(1),(1),(1),(1),(1),(1),(1),(1),(1),(1),(1)) AS x(n)) -- 16 records
			,e4(n) AS (SELECT 1 FROM e1 a CROSS JOIN e1 b CROSS JOIN e1 c CROSS JOIN e1 d) -- 16^4 or 65,536 records (256*256)
			,e15(n) AS (SELECT 1 FROM e4 a CROSS JOIN e4 b CROSS JOIN e4 c CROSS JOIN e1 d CROSS JOIN e1 e CROSS JOIN e1 f) -- 16^15 or 1,152,921,504,606,846,976 records
			,emax(n) AS (
				SELECT	TOP ((CASE WHEN @StopVal > @StartVal THEN @StopVal-@StartVal ELSE @StartVal-@StopVal END + ABS(@StepVal)) / ABS(@StepVal))
						ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS n
				FROM	(SELECT 1 FROM e15 a CROSS JOIN (VALUES (1),(1),(1),(1),(1),(1),(1),(1)) x(n)) AS x(n)
				) -- 16^15*8 (2^63) or 9,223,372,036,854,775,807 records (largest size for a BIGINT value) -- over 9 quintillion!!
		SELECT 	((n - 1) * @StepVal) + @StartVal as generate_series
		FROM 	emax
		WHERE 	((n - 1) * @StepVal) + @StartVal BETWEEN CASE WHEN @StopVal > @StartVal THEN @StartVal ELSE @StopVal END AND CASE WHEN @StopVal > @StartVal THEN @StopVal ELSE @StartVal END;
	GO

--
-- Let's test the Generate Series function
--
	SELECT * FROM dbo.fnGenerate_Series(5,1,-2);
	GO