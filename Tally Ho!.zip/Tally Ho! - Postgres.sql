/*
 *	How it works:
 */
-- Data Rows
	select StringValue
	from (values('One',1),('Two',2),('Three',3),('Four',4),('Five',5)) as s(StringValue,SortValue)
	order by SortValue;

-- Tally table Rows
	select n
	from (values(1),(2),(3),(4),(5),(6),(7),(8),(9),(10)) as t(n);

	select n from generate_series(1, 10) as t(n);

-- Data Rows cross joined with tally table rows
	select n, StringValue
	from (values('One',1),('Two',2),('Three',3),('Four',4),('Five',5)) as s(StringValue,SortValue)
	inner join generate_series(1, 10) as t(n)
		on 1 = 1
	order by SortValue, n;

-- Limit results to where n is the number of characters in the string
	select n, StringValue
	from (values('One',1),('Two',2),('Three',3),('Four',4),('Five',5)) as s(StringValue,SortValue)
	inner join generate_series(1,10) as t(n)
		on n <= length(StringValue)
	order by SortValue, n;

-- Making use of tally rows to "loop" through strings and highlight each letter
	select n, case when n=1 then '' else left(StringValue, n-1) end || '>' ||
				substring(StringValue, n, 1) || '<' ||
				case when n=length(StringValue) then '' else substring(StringValue, n+1, 8000) END AS StringValue
	from (values('One',1),('Two',2),('Three',3),('Four',4),('Five',5)) AS s(StringValue,SortValue)
	inner join generate_series(1,10) t(n)
		on n <= length(StringValue)
	order by SortValue, n;

-- How exponential growth is utilized
	with e1(n) as (select n from (values (1),(1),(1),(1),(1),(1),(1),(1),(1),(1),(1),(1),(1),(1),(1),(1)) as x(n)) -- 16 records
		,e2(n) as (select 1 from e1 a, e1 b) -- 16^2 or 256 records (16*16)
--		,e4(n) as (select 1 from e2 a, e2 b) -- 16^4 or 65,536 records (256*256)
--		,e8(n) as (select 1 from e4 a, e4 b) -- 16^8 or 4,294,967,296 records (65,536*65,536)
	select row_number() over (order by 1) as n
	from e2
	order by n;

-- For PostgreSQL, use the generate_series function:
	select n from generate_series(1, 256) as t(n);
--
----------------------------------------------------------------------------------------------------------------------------------------
--

/*
 *	Create as a table function utilizing increasing exponential growth
 *	Advantage is that this is in memory only with no disk I/O required
 */

	/*
	 * Platform: Microsoft SQL Server
	 *     Returns a table of sequence values based on the parameters
	 * Function: fnTally
	 *     Returns a table of sequence values based on the parameters
	 * Parameters:
	 *     @RowCnt    : The number of rows to be generated 
	 *     @ZeroOrOne : Indicate the starting value of either 0 or 1
	 */
	CREATE FUNCTION dbo.fnTally(@RowCnt bigint, @ZeroOrOne bit = 1)
	RETURNS TABLE WITH SCHEMABINDING
	AS RETURN
		WITH e1(n) AS (SELECT n FROM (VALUES (1),(1),(1),(1),(1),(1),(1),(1),(1),(1),(1),(1),(1),(1),(1),(1)) AS x(n)) -- 16 records
			,e4(n) AS (SELECT 1 FROM e1 a CROSS JOIN e1 b CROSS JOIN e1 c CROSS JOIN e1 d) -- 16^4 or 65,536 records (256*256)
		SELECT TOP (@RowCnt-CAST(@ZeroOrOne AS BIGINT)) ROW_NUMBER() OVER (ORDER BY (SELECT 1)) - (CAST(~@ZeroOrOne AS BIGINT)) AS n
		FROM (SELECT 1 FROM e4 a CROSS JOIN e4 b); -- 16^8 or 4,294,967,296 records (65,536*65,536)
	GO

--
----------------------------------------------------------------------------------------------------------------------------------------
--

/*
 *	Example 1:	I want to find out how many people have a birthday in each month but I don't want to
 *				skip any months.
 */

-- Let's populate a table with our data
	drop table if exists PersonList;
	create temporary table PersonList (
			PersonID int,
			FirstName varchar(32),
			LastName varchar(32),
			DOB date
			);

	insert  into PersonList (PersonID, FirstName, LastName, DOB)
	values	(123456, 'Duck', 'Daffy', '03/05/1964'),
			(234567, 'Bunny', 'Bugs', '02/29/1964'),
			(345678, 'Coyote', 'Wile', '01/15/1966'),
			(456789, 'Runner', 'Road', '04/23/1974'),
			(567890, 'Duck', 'Daisy', '05/03/1966'),
			(564231, 'Fudd', 'Elmer', '03/20/1946'),
			(853156, 'Bird', 'Tweety', '10/10/1960'),
			(462137, 'Cat', 'Sylvester', '12/15/1955'),
			(134679, 'LePue', 'Peppy', '11/11/1959'),
			(963741, 'Duck', 'Huey', '09/09/1979'),
			(963742, 'Duck', 'Louie', '09/09/1979'),
			(963743, 'Duck', 'Dewey', '09/09/1979');


-- Normally I'd use this query
	select date_part('month', DOB) as BirthMonth, count(*) as CountNbr
	from PersonList
	group by date_part('month', DOB)
	order by 1,2;

-- However, this will not return a row for any month that did not have a birthday.  You can use a
-- tally to ensure that you have totals for all 12 months, even for months without a birthday.
	select t.n AS BirthMonth, count(date_part('month', pl.DOB)) AS CountNbr
	from generate_series(1,12) as t(n)
	left join PersonList pl
		on n = date_part('month', pl.DOB)
	group by t.n
	order by 1,2;
--
----------------------------------------------------------------------------------------------------------------------------------------
--

/*
 *	Example 2:	Let's say that you need to generate a list of all dates for the third milennium
 *				inclusive. You might use a temp table or table variable, and construct a loop that
 *				inserts records for each date in the range. By using a tally table, all you need is
 *				this (using variables to make it flexible):
 */
	select	d::date as FullDate,
			date_part('day', d) as DayValue,
			date_part('month', d) as MonthValue,
			date_part('year', d) as YearValue
	from generate_series(date '2000-01-01', date '2999-12-31', '1 day') as t(d);

--
----------------------------------------------------------------------------------------------------------------------------------------
--

/*
 *	Example 3:	Break strings into multiple segments of a given length or less.
 */
-- Let's populate a table with our data
	drop table if exists temporary_table;
	create temporary table IrishJoke (
				StringId int,
				StringValue varchar(256)
				);
	insert into IrishJoke (StringId, StringValue)
	values  (1, 'Three Irishmen, Paddy, Sean and Seamus, were stumbling home from the pub late one night and found themselves on the road which led past the old graveyard.'),
			(2, '"Come have a look over here," says Paddy, "It''s Michael O''Grady''s grave, God bless his soul. He lived to the ripe old age of 87."'),
			(3, '"That''s nothing," says Sean, "here''s one named Patrick O''Toole, it says here that he was 95 when he died."'),
			(4, 'Just then, Seamus yells out, "Good God, here''s a fella that got to be 145!"'),
			(5, '"What was his name?" asks Paddy.'),
			(6, 'Seamus stumbles around a bit, awkwardly lights a match to see what else is written on the stone marker, and exclaims, "Miles, from Dublin."');

	select ij.StringId, t.n AS SegmentNbr, substring(ij.StringValue, (t.n * 50) + 1, 50) AS SegmentStr
	from IrishJoke AS ij
	inner join generate_series(0, 10) as t(n)
		on length(ij.StringValue) - (t.n * 50) > 0
	order by ij.StringId, t.n;

--
----------------------------------------------------------------------------------------------------------------------------------------
--

/*
 *	Example 4:	Break strings according to delimiter
 */
--
-- Create as a generic Inline Table-Value Function
--
	IF OBJECT_ID(N'dbo.fnSplitString', N'IF') IS NOT NULL DROP FUNCTION dbo.fnSplitString;
	GO
	/*
	 * Function: fnSplitString
	 *     Returns a table of string segments based upon the given delimiter
	 * Parameters:
	 *     @StringValue : The string value to be split
	 *     @Delimiter   : The delimiter to be used in splitting the string
	 */
	CREATE FUNCTION dbo.fnSplitString(@StringValue VARCHAR(8000), @Delimiter VARCHAR(1))
	RETURNS TABLE WITH SCHEMABINDING
	AS RETURN
		WITH cteStartPos(StartPos) AS (
			SELECT 1
			UNION ALL
			SELECT n+1
			FROM dbo.fnTally(LEN(@StringValue), 1)
			WHERE SUBSTRING(@StringValue, n, 1) = @Delimiter
			),
		cteSegmentLen(StartPos, StringLen) AS (
			SELECT StartPos, ISNULL(NULLIF(CHARINDEX(@Delimiter, @StringValue, StartPos), 0) - StartPos, (LEN(@StringValue)-StartPos)+1)
			FROM cteStartPos
			)
		SELECT	ROW_NUMBER() OVER (ORDER BY StartPos) AS SegmentNbr,
				SUBSTRING(@StringValue, StartPos, StringLen) AS SegmentStr
		FROM cteSegmentLen;
	GO

--
-- Use the procedural function
--
	SELECT ij.StringId, ss.SegmentNbr, ss.SegmentStr
	FROM #IrishJoke AS ij
	CROSS APPLY dbo.udfSplitString(ij.StringValue, ',') AS ss
	ORDER BY ij.StringId, ss.SegmentNbr;
	GO
--
-- Use the function based on tally
--
	SELECT ij.StringId, ss.SegmentNbr, ss.SegmentStr
	FROM #IrishJoke AS ij
	CROSS APPLY dbo.fnSplitString(ij.StringValue, ',') AS ss
	ORDER BY ij.StringId, ss.SegmentNbr;
	GO

--
----------------------------------------------------------------------------------------------------------------------------------------
--

/*
 * Example 5:	Create test data
 */
	IF OBJECT_ID(N'tempdb..#TestData', N'U') IS NOT NULL DROP TABLE #TestData;
	CREATE TABLE #TestData(ID INT IDENTITY(1,1), DataString VARCHAR(50));

-- Usual method
-- This method performs a loop of 1000 INSERT INTO statements
	INSERT INTO #TestData (DataString) VALUES (NEWID());
	GO 1000

-- Tally method
-- This method performs a single INSERT INTO statement in set-based method
	TRUNCATE TABLE #TestData;
	INSERT INTO #TestData(DataString)
	SELECT NEWID()
	FROM dbo.fnTally(1000, 1);
	GO

--
----------------------------------------------------------------------------------------------------------------------------------------
--

/*
 * Example 6:	Generate Prime numbers up to 1000
 */
-- Tally method (set-based)
	select n AS Prime
	from generate_series(1,1000) as N1(n)
    where not exists (							-- Correlated sub-query
		select	1
		from	generate_series(2,1000) as N2(n)
		where	N2.n < N1.n						-- We only need to test numbers less than the current number
			and N1.n % (N2.n) = 0				-- Check to see if there are any numbers that evenly divide in
		)
	order by n;
--
----------------------------------------------------------------------------------------------------------------------------------------
--

/*
 * Advanced Functions:
 */

-- Be aware that the new STRING_SPLIT() function has several problems (Thanks to Jeff Moden):
--
-- 1. If you pass it a NULL, it returns no rows... not even a NULL.  This is atypical behavior for most string functions.
-- 2. The function does not return the ordinal position of the element being split out.  That also means...
-- 3. There is no guarantee of sort order.

--
-- Self-contained string split:
--
	IF OBJECT_ID(N'dbo.fnSplitString', N'IF') IS NOT NULL DROP FUNCTION dbo.fnSplitString;
	GO
	/*
	 * Function: fnSplitString
	 *     Returns a table of segments of a given string separated by a given delimiter
	 * Parameters:  
	 *     @StringValue : The string to be split
	 *     @Delimiter   : The delimiter used to identify segments of the string
	 */
	CREATE FUNCTION dbo.fnSplitString(@StringValue VARCHAR(8000), @Delimiter VARCHAR(1))
	RETURNS TABLE WITH SCHEMABINDING
	AS RETURN
		WITH e1(n) AS (SELECT n FROM (VALUES (1),(1),(1),(1),(1),(1),(1),(1),(1),(1),(1),(1),(1),(1),(1),(1)) AS x(n)) -- 16 records
			,cteTally(n) AS (
				SELECT TOP(LEN(@StringValue)) ROW_NUMBER() OVER (ORDER BY (SELECT 1))
				FROM e1 a CROSS JOIN e1 b CROSS JOIN e1 c CROSS JOIN (VALUES (1),(1)) AS d(n) -- 16^3 * 2 or 8192 records
				)
			,cteStartPos(StartPos) AS (
				SELECT 1
				UNION ALL
				SELECT n+1 FROM cteTally WHERE SUBSTRING(@StringValue, n, 1) = @Delimiter
				)
			,cteSegmentLen(StartPos, StringLen) AS (
				SELECT StartPos, ISNULL(NULLIF(CHARINDEX(@Delimiter, @StringValue, StartPos), 0) - StartPos, (LEN(@StringValue)-StartPos)+1)
				FROM cteStartPos
				)
		SELECT	ROW_NUMBER() OVER (ORDER BY StartPos) AS SegmentNbr,
				SUBSTRING(@StringValue, StartPos, StringLen) AS SegmentStr
		FROM cteSegmentLen;
	GO

--
-- Self-contained date range generator:
--
	IF OBJECT_ID(N'dbo.fnDateRange', N'IF') IS NOT NULL DROP FUNCTION dbo.fnDateRange;
	GO
	/*
	 * Function: fnDateRange
	 *     Returns a table of date values from the Start Date through the End Date
	 * Parameters:  
	 *     @StartDate : The date to start the sequence
	 *     @EndDate   : The date to end the sequence
	 */
	CREATE FUNCTION dbo.fnDateRange(@StartDate AS DATE, @EndDate AS DATE)
	RETURNS TABLE WITH SCHEMABINDING AS
		WITH e1(n) AS (SELECT n FROM (VALUES (1),(1),(1),(1),(1),(1),(1),(1),(1),(1),(1),(1),(1),(1),(1),(1)) AS x(n)) -- 16 records
			,e4(n) AS (SELECT 1 FROM e1 a CROSS JOIN e1 b CROSS JOIN e1 c CROSS JOIN e1 d) -- 16^4 or 65,536 records (256*256)
			,cteTally(n) AS (
				SELECT TOP(DATEDIFF(DAY, @StartDate, @EndDate)+1) ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS n
				FROM e4 a CROSS JOIN e4 b	-- 16^8 or 4,294,967,296 records (65,536*65,536)
				)
		SELECT DATEADD(DAY, n-1, @StartDate) AS DateVal
		FROM cteTally;
	GO

--
-- A Tally function where you specify not only a top value, but an offset value and an increment to generate values up to the bigint max value
--
	IF OBJECT_ID(N'dbo.fnUltimateTally', N'IF') IS NOT NULL DROP FUNCTION dbo.fnUltimateTally;
	GO
	/*
	 * Function: fnUltimateTally
	 *     Returns a table of sequence values based on the parameters up to the largest value of a bigint
	 * Parameters:  
	 *     @RowCnt   : The number of rows to be generated 
	 *     @StartVal : The starting value
	 *     @IncrVal  : The incremental value
	 */
	CREATE FUNCTION dbo.fnUltimateTally(@RowCnt bigint, @StartVal bigint = 1, @IncrVal bigint = 1)
	RETURNS TABLE WITH SCHEMABINDING
	AS RETURN
		WITH e1(n) AS (SELECT n FROM (VALUES (1),(1),(1),(1),(1),(1),(1),(1),(1),(1),(1),(1),(1),(1),(1),(1)) AS x(n)) -- 16 records
			,e4(n) AS (SELECT 1 FROM e1 a CROSS JOIN e1 b CROSS JOIN e1 c CROSS JOIN e1 d) -- 16^4 or 65,536 records (256*256)
			,e15(n) AS (SELECT 1 FROM e4 a CROSS JOIN e4 b CROSS JOIN e4 c CROSS JOIN e1 d CROSS JOIN e1 e CROSS JOIN e1 f) -- 16^15 or 1,152,921,504,606,846,976 records
			,emax(n) AS (SELECT TOP (ISNULL(ABS(@RowCnt+@StartVal-1) / ABS(@IncrVal), @RowCnt)) ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS n
						FROM (SELECT 1 FROM e15 a CROSS JOIN (VALUES (1),(1),(1),(1),(1),(1),(1),(1)) x(n)) AS x(n)) -- 16^15*8 (2^63) or 9,223,372,036,854,775,807 records
		SELECT ((n - 1) * @IncrVal) + @IncrVal as n
		FROM emax
		WHERE n >= @StartVal;
	GO

--
-- Create a more detailed Date/Time Range to include increments and date/time parts
--
	IF OBJECT_ID(N'dbo.fnDateTimeRange', N'IF') IS NOT NULL DROP FUNCTION dbo.fnDateTimeRange;
	GO
	/*
	 * Function: fnDateTimeRange
	 *     Returns a table of datetime values based on the parameters
	 * Parameters:  
	 *     @StartDate : Start date of the series 
	 *     @EndDate   : End date of the series 
	 *     @DatePart  : The time unit for @interval
	 *         ns     : nanoseconds 
	 *         mcs    : microseconds 
	 *         ms     : milliseconds 
	 *         ss     : seconds
	 *         mi     : minutes
	 *         hh     : hours
	 *         dd     : days
	 *         ww     : weeks
	 *         mm     : months
	 *         qq     : quarters
	 *         yy     : years
	 *     @Interval  : The number of dateparts between each value returned
	 */
	CREATE FUNCTION dbo.fnDateTimeRange(@StartDate datetime2, @EndDate datetime2, @DatePart varchar(3)='dd', @Interval int=1)
	RETURNS TABLE WITH SCHEMABINDING
	AS RETURN
		WITH e1(n) AS (SELECT n FROM (VALUES (1),(1),(1),(1),(1),(1),(1),(1),(1),(1),(1),(1),(1),(1),(1),(1)) AS x(n)) -- 16 records
			,e4(n) AS (SELECT 1 FROM e1 a CROSS JOIN e1 b CROSS JOIN e1 c CROSS JOIN e1 d) -- 16^4 or 65,536 records (256*256)
			,cteTally(seqnbr, direction) AS (
				SELECT TOP(ABS(CASE @DatePart WHEN 'ns'  THEN DATEDIFF(ns, @EndDate, @StartDate)/@Interval
											  WHEN 'mcs' THEN DATEDIFF(mcs,@EndDate, @StartDate)/@Interval
											  WHEN 'ms'  THEN DATEDIFF(ms, @EndDate, @StartDate)/@Interval
											  WHEN 'ss'  THEN DATEDIFF(ss, @EndDate, @StartDate)/@Interval
											  WHEN 'mi'  THEN DATEDIFF(mi, @EndDate, @StartDate)/@Interval
											  WHEN 'hh'  THEN DATEDIFF(hh, @EndDate, @StartDate)/@Interval
											  WHEN 'dd'  THEN DATEDIFF(dd, @EndDate, @StartDate)/@Interval
											  WHEN 'ww'  THEN DATEDIFF(ww, @EndDate, @StartDate)/@Interval
											  WHEN 'mm'  THEN DATEDIFF(mm, @EndDate, @StartDate)/@Interval
											  WHEN 'qq'  THEN DATEDIFF(qq, @EndDate, @StartDate)/@Interval
											  WHEN 'yy'  THEN DATEDIFF(yy, @EndDate, @StartDate)/@Interval
											  ELSE		 ABS(DATEDIFF(dd, @EndDate, @StartDate))/@Interval
											  END) + 1)
						ROW_NUMBER() OVER (ORDER BY (SELECT 1)) - 1,
						CASE WHEN @StartDate < @EndDate THEN 1 ELSE -1 END
				FROM e4 a CROSS JOIN e4 b	-- 16^8 or 4,294,967,296 records (65,536*65,536)
				)
		SELECT CASE @DatePart WHEN 'ns'  THEN DATEADD(ns, direction * seqnbr * @interval, @StartDate)
							  WHEN 'mcs' THEN DATEADD(mcs,direction * seqnbr * @interval, @StartDate)
							  WHEN 'ms'  THEN DATEADD(ms, direction * seqnbr * @interval, @StartDate)
							  WHEN 'ss'  THEN DATEADD(ss, direction * seqnbr * @interval, @StartDate)
							  WHEN 'mi'  THEN DATEADD(mi, direction * seqnbr * @interval, @StartDate)
							  WHEN 'hh'  THEN DATEADD(hh, direction * seqnbr * @interval, @StartDate)
							  WHEN 'dd'  THEN DATEADD(dd, direction * seqnbr * @interval, @StartDate)
							  WHEN 'ww'  THEN DATEADD(ww, direction * seqnbr * @interval, @StartDate)
							  WHEN 'mm'  THEN DATEADD(mm, direction * seqnbr * @interval, @StartDate)
							  WHEN 'qq'  THEN DATEADD(qq, direction * seqnbr * @interval, @StartDate)
							  WHEN 'yy'  THEN DATEADD(yy, direction * seqnbr * @interval, @StartDate)
							  ELSE            DATEADD(dd, direction * seqnbr * @interval, @StartDate)
							  END AS DateTimeValue
		FROM cteTally;
	GO