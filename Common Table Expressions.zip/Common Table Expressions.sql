/*
 * Discover the Hidden Mysteries of Common Table Expressions
 * By Aaron N. Cutshall (c) 2018
 *
 */


--
-- Start Demo 1
--

USE AdventureWorks2014;

-- Creating a simple common table expression:
--     The following example shows the total number of sales orders per year for each sales representative at Adventure Works Cycles.
--     Compare execution plans for both of the following queries:

  -- Typical query with sub-query:
	-- Primary Query
	SELECT	SalesPersonID, COUNT(SalesOrderID) AS TotalSales, SalesYear
	FROM (
		-- Sub-query to obtain specific data
		SELECT	SalesPersonID, SalesOrderID, YEAR(OrderDate) AS SalesYear
		FROM	Sales.SalesOrderHeader
		WHERE	SalesPersonID IS NOT NULL
		) AS s
	GROUP BY SalesYear, SalesPersonID
	ORDER BY SalesPersonID, SalesYear;

  -- Same effective query as above but using a CTE
	-- Define the CTE expression name and column list
	WITH cteSales (SalesPersonID, SalesOrderID, SalesYear) AS (
		-- Define the CTE query
		SELECT	SalesPersonID, SalesOrderID, YEAR(OrderDate)
		FROM	Sales.SalesOrderHeader
		WHERE	SalesPersonID IS NOT NULL
		)
	-- Define the outer query referencing the CTE name
	SELECT	SalesPersonID, COUNT(SalesOrderID) AS TotalSales, SalesYear
	FROM	cteSales
	GROUP BY SalesYear, SalesPersonID
	ORDER BY SalesPersonID, SalesYear;

-- Using a common table expression to limit counts and report averages:
--     The following example shows the average number of sales orders for all years for the sales representatives.
	WITH cteSales (SalesPersonID, NumberOfOrders) AS (
		SELECT	SalesPersonID, COUNT(1)
		FROM	Sales.SalesOrderHeader
		WHERE	SalesPersonID IS NOT NULL
		GROUP BY SalesPersonID
		)
	SELECT AVG(NumberOfOrders) AS "Average Sales Per Person"
	FROM cteSales;

-- Using multiple CTE definitions in a single query
--     The following example shows how to define more than one CTE in a single query.
--     Notice that a comma is used to separate the CTE query definitions.
--     The FORMAT function, used to display the monetary amounts in a currency format, is available in SQL Server 2012 and higher.
	WITH cteSales (SalesPersonID, TotalSales, SalesYear) AS (
		-- Define the first CTE query.  
		SELECT	SalesPersonID, SUM(TotalDue) AS TotalSales, YEAR(OrderDate) AS SalesYear
		FROM	Sales.SalesOrderHeader
		WHERE	SalesPersonID IS NOT NULL
		GROUP BY SalesPersonID, YEAR(OrderDate)
		), -- Use a comma to separate multiple CTE definitions.  
	-- Define the second CTE query, which returns sales quota data by year for each sales person.  
	cteSalesQuota (BusinessEntityID, SalesQuota, SalesQuotaYear) AS (
		SELECT	BusinessEntityID, SUM(SalesQuota)AS SalesQuota, YEAR(QuotaDate) AS SalesQuotaYear  
		FROM	Sales.SalesPersonQuotaHistory  
		GROUP BY BusinessEntityID, YEAR(QuotaDate)  
		)  
	-- Define the outer query by referencing columns from both CTEs.  
	SELECT	s.SalesPersonID,
			s.SalesYear,
			FORMAT(s.TotalSales,'C','en-us') AS TotalSales,
			sq.SalesQuotaYear,
			FORMAT (sq.SalesQuota,'C','en-us') AS SalesQuota,
			FORMAT (s.TotalSales - sq.SalesQuota, 'C','en-us') AS Amt_Above_or_Below_Quota
	FROM	cteSales s
	INNER JOIN cteSalesQuota sq
		ON  sq.BusinessEntityID = s.SalesPersonID  
		AND sq.SalesQuotaYear = s.SalesYear  
	ORDER BY s.SalesPersonID, s.SalesYear;

	-- What are the top 10 best selling items per weekday for each year?

--
-- End Demo 1
--

--
-- Start Demo 2
--

--
-- Recursive CTEs
--

--
-- Generate a Factorial sequence: F(n) = n * F(n-1)
--
	DECLARE @n INT = 10;
	WITH cteFactorial (n, Factorial) AS (
		-- Base member definition
		SELECT	1, CAST(1 AS BIGINT)	-- By default a literal number has a data type of INT
		UNION ALL
		-- Recursive member definition
		SELECT	n+1, (n+1) * Factorial
		FROM	cteFactorial
		WHERE	n < @n
		)
	-- Statement that executes the CTE
	SELECT	n, Factorial
	FROM	cteFactorial;

--
-- The following example shows the hierarchical list of managers and the employees who report to them.
-- The example begins by creating and populating the #MyEmployees table.
--

	-- Create an Employee table
	CREATE TABLE #MyEmployees (
		EmployeeID smallint NOT NULL,
		FirstName varchar(30) NOT NULL,
		LastName  varchar(40) NOT NULL,
		Title varchar(50) NOT NULL,
		DeptID smallint NOT NULL,
		ManagerID int NULL,
		CONSTRAINT PK_EmployeeID PRIMARY KEY CLUSTERED (EmployeeID ASC)
		);  

	-- Populate the table with values
	INSERT INTO #MyEmployees VALUES
		(1, N'Ken', N'S�nchez', N'Chief Executive Officer',16,NULL),
		(273, N'Brian', N'Welcker', N'Vice President of Sales',3,1),
		(274, N'Stephen', N'Jiang', N'North American Sales Manager',3,273),
		(275, N'Michael', N'Blythe', N'Sales Representative',3,274),
		(276, N'Linda', N'Mitchell', N'Sales Representative',3,274),
		(285, N'Syed', N'Abbas', N'Pacific Sales Manager',3,273),
		(286, N'Lynn', N'Tsoflias', N'Sales Representative',3,285),
		(16,  N'David',N'Bradley', N'Marketing Manager', 4, 273),
		(23,  N'Mary', N'Gibson', N'Marketing Specialist', 4, 16);  

	-- Declare the recursive CTE
	WITH cteManagers(ManagerID, EmployeeID, Title, EmployeeLevel) AS (
		-- Declare the base case
		SELECT	ManagerID, EmployeeID, Title, 1 AS EmployeeLevel
		FROM	#MyEmployees
		WHERE	ManagerID IS NULL
		-- Combine both parts with UNION ALL
		UNION ALL
		-- Declare the recursive case
		SELECT	e.ManagerID, e.EmployeeID, e.Title, m.EmployeeLevel + 1
		FROM	#MyEmployees AS e
		INNER JOIN cteManagers AS m
			ON m.EmployeeID = e.ManagerID 
		)
	SELECT	ManagerID, EmployeeID, Title, EmployeeLevel
	FROM	cteManagers
	ORDER BY ManagerID;

-- Using a recursive common table expression to display two levels of recursion
-- The following example shows managers and the employees reporting to them.
-- The number of levels returned is limited to two.
	WITH cteManagers(ManagerID, EmployeeID, Title, EmployeeLevel) AS (
		SELECT	ManagerID, EmployeeID, Title, 1 AS EmployeeLevel  
		FROM	#MyEmployees
		WHERE	ManagerID IS NULL
		UNION ALL
		SELECT	e.ManagerID, e.EmployeeID, e.Title, m.EmployeeLevel + 1
		FROM	#MyEmployees AS e
		INNER JOIN cteManagers AS m
			ON	m.EmployeeID = e.ManagerID
		)
	SELECT	ManagerID, EmployeeID, Title, EmployeeLevel
	FROM	cteManagers
	WHERE	EmployeeLevel <= 2;

-- Using a recursive common table expression to display a hierarchical list
-- The following example builds on the previous by adding the names of the manager and employees,
-- and their respective titles. The hierarchy of managers and employees is additionally emphasized
-- by indenting each level.

	WITH DirectReports(Name, Title, EmployeeID, EmployeeLevel, Sort) AS (
		SELECT	CONVERT(varchar(255), e.FirstName + ' ' + e.LastName),
				e.Title,
				e.EmployeeID,
				1,
				CONVERT(varchar(255), e.FirstName + ' ' + e.LastName)
		FROM	#MyEmployees AS e
		WHERE	e.ManagerID IS NULL
		UNION ALL
		SELECT	CONVERT(varchar(255), REPLICATE ('|    ' , EmployeeLevel) + e.FirstName + ' ' + e.LastName),
				e.Title,
				e.EmployeeID,
				EmployeeLevel + 1,
				CONVERT (varchar(255), RTRIM(Sort) + '|    ' + FirstName + ' ' +  LastName)
		FROM	#MyEmployees AS e
		INNER JOIN DirectReports AS d
			ON	d.EmployeeID = e.ManagerID
		)
	SELECT	EmployeeID, Name, Title, EmployeeLevel
	FROM	DirectReports
	ORDER BY Sort;

-- Using MAXRECURSION to cancel a statement
-- MAXRECURSION can be used to prevent a poorly formed recursive CTE from entering into an infinite loop.
-- The following example intentionally creates an infinite loop and uses the MAXRECURSION hint to limit
-- the number of recursion levels to two.

--Creates an infinite loop  
	WITH cteManager (EmployeeID, ManagerID, Title, EmployeeLevel) AS (
		SELECT	EmployeeID, ManagerID, Title, 1
		FROM	#MyEmployees
		WHERE	ManagerID IS NOT NULL 		-- All employees with a manager
		UNION ALL
		SELECT	m.EmployeeID, m.ManagerID, m.Title, m.EmployeeLevel+1
		FROM	cteManager m
		INNER JOIN #MyEmployees AS e
			ON	e.EmployeeID = m.ManagerID	-- All managers are employees, so data set will always exist
		)
	--Uses MAXRECURSION to limit the recursive levels to 2
	SELECT	EmployeeID, ManagerID, Title, EmployeeLevel
	FROM	cteManager
	OPTION (MAXRECURSION 2);

	-- After the coding error is corrected, MAXRECURSION is no longer required.
	-- The following example shows the corrected code.
	WITH cteManager (EmployeeID, ManagerID, Title, EmployeeLevel) AS  (
		SELECT	EmployeeID, ManagerID, Title, 1
		FROM	#MyEmployees
		WHERE	ManagerID IS NULL		-- Only employees without a manager (CEO)
		UNION ALL
		SELECT	e.EmployeeID, e.ManagerID, e.Title, EmployeeLevel+1
		FROM #MyEmployees AS e
		INNER JOIN cteManager m
			ON	m.EmployeeID = e.ManagerID	-- Get the manager for a given employee
		)
	SELECT	EmployeeID, ManagerID, Title, EmployeeLevel
	FROM	cteManager;

-- Using multiple base and recursive members
-- The following example uses multiple base and recursive members to return all the ancestors of a specified person.
-- A table is created and values inserted to establish the family genealogy returned by the recursive CTE.

-- Genealogy table  
	CREATE TABLE #Person(ID int, Name varchar(30), Mother int, Father int);  

	INSERT #Person(ID, Name, Mother, Father)
		VALUES	(1, 'Sue', NULL, NULL),
				(2, 'Ed', NULL, NULL),
				(3, 'Emma', 1, 2),
				(4, 'Jack', 1, 2),
				(5, 'Jane', NULL, NULL),
				(6, 'Bonnie', 5, 4),
				(7, 'Bill', 5, 4);

	-- Create the recursive CTE to find all of Bonnie's ancestors.  
	WITH cteGeneration (ID) AS (
	-- First base member returns Bonnie's mother.
		SELECT	Mother
		FROM	#Person
		WHERE	Name = 'Bonnie'
		UNION  
	-- Second base member returns Bonnie's father.
		SELECT	Father
		FROM	#Person
		WHERE	Name = 'Bonnie'
		UNION ALL
	-- First recursive member returns male ancestors of the previous generation.
		SELECT	p.Father
		FROM	cteGeneration g
		INNER JOIN #Person p
			ON	p.ID = g.ID
		UNION ALL
	-- Second recursive member returns female ancestors of the previous generation.
		SELECT	p.Mother
		FROM	cteGeneration g
		INNER JOIN #Person p
			ON	p.ID = g.ID
		)
	SELECT	p.ID, p.Name, p.Mother, p.Father
	FROM	cteGeneration g
	INNER JOIN #Person p
		ON	p.ID = g.ID;

--
-- Using analytical functions in a recursive CTE
-- The following example shows a pitfall that can occur when using an analytical
-- or aggregate function in the recursive part of a CTE.
--
	WITH cteData AS (
		SELECT	itmID, itmIDComp
		FROM	(VALUES (1,10), (2,10), (3,10), (4,10)) AS d(itmID, itmIDComp)
		),
	cteRecursion AS (
		SELECT	t.itmID AS itmIDComp, NULL AS itmID, CAST(0 AS bigint) AS N, 1 AS Lvl  
		FROM (VALUES (1),(2),(3),(4)) AS t(itmID)   
		UNION ALL
		SELECT	t.itmIDComp, t.itmID, ROW_NUMBER() OVER(PARTITION BY t.itmIDComp ORDER BY t.itmIDComp, t.itmID) AS N, Lvl + 1
		FROM cteRecursion r
		INNER JOIN cteData AS t
			ON	t.itmID = r.itmIDComp
		)
	SELECT	Lvl, N
	FROM	cteRecursion;

	/* The following results are the expected results for the query.
		Lvl  N
		1    0
		1    0
		1    0
		1    0
		2    4
		2    3
		2    2
		2    1

	The following results are the actual results for the query.
		Lvl  N
		1    0
		1    0
		1    0
		1    0
		2    1
		2    1
		2    1
		2    1

	N returns 1 for each pass of the recursive part of the CTE because only the subset of data for
	that recursion level is passed to ROWNUMBER. For each of the iterations of the recursive part
	of the query, only one row is passed to ROWNUMBER.
	*/

--
-- End Demo 2
--


--
-- Start Demo 3
--

--
-- Tips & Tricks
--
	GO
-- Create a Tally Table Function
	-- Create as a table function utilizing increasing exponential growth
	-- Advantage is that this is in memory only with no disk I/O required
	CREATE FUNCTION dbo.fnTally(@n int)
	RETURNS TABLE WITH SCHEMABINDING
	AS RETURN
		WITH e1(n) AS (SELECT n FROM (VALUES (1),(1),(1),(1),(1),(1),(1),(1),(1),(1)) AS x(n)) -- 10 records
			,e2(n) AS (SELECT 1 FROM e1 a CROSS JOIN e1 b) -- 100 records (10*10)
			,e4(n) AS (SELECT 1 FROM e2 a CROSS JOIN e2 b) -- 10,000 records (100*100)
			,e8(n) AS (SELECT 1 FROM e4 a CROSS JOIN e4 b) -- 100,000,000 records (10,000*10,000)
		SELECT TOP (@n) ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) AS n
		FROM e8; -- TOP statement will select records as needed
	GO

-- Delete Duplicate Data - typically used in staging tables without primary key
	CREATE TABLE #Patients (
		PatientKey int IDENTITY(1,1),
		PatientID int NOT NULL,
		LastName varchar(40) NOT NULL,
		FirstName varchar(40) NULL,
		MiddleInit char(1) NULL,
		Gender char(1) NULL,
		DOB date NULL
		);

	INSERT INTO #Patients(PatientID, LastName, FirstName, MiddleInit, Gender, DOB)
		VALUES  (123456, 'Duck', 'Daffy', 'D', 'M', '03/05/1964'),
				(234567, 'Bunny', 'Bugs', 'B', 'M', '02/29/1964'),
				(345678, 'Coyote', 'Wile', 'E', 'M', '01/15/1966'),
				(123456, 'Duck', 'Daffy', 'D', 'M', '03/05/1964'), -- Duplicate
				(456789, 'Runner', 'Road', NULL, 'F', '04/23/1974'),
				(345678, 'Coyote', 'Whylee', NULL, NULL, '01/15/1966'), -- Duplicate
				(123456, 'Duck', 'Daffy', 'D', 'M', '03/05/1964'), -- Duplicate
				(567890, 'Duck', 'Daisy', NULL, 'F', '05/03/1966'),
				(564231, 'Fudd', 'Elmer', NULL, 'M', '03/20/1946'),
				(853156, 'Bird', 'Tweety', NULL, 'M', '10/10/1960'),
				(462137, 'Cat', 'Sylvester', 'T', 'M', '12/15/1955'),
				(134679, 'LePue', 'Peppy', NULL, 'M', '11/11/1959'),
				(963741, 'Duck', 'Huey', NULL, 'M', '09/09/1979'),
				(963742, 'Duck', 'Louie', NULL, 'M', '09/09/1979'),
				(963743, 'Duck', 'Dewey', NULL, 'M', '09/09/1979');

	SELECT * FROM #Patients ORDER BY PatientID;

	-- Show duplicate data
	WITH cteDups AS (
		SELECT *, ROW_NUMBER() OVER(PARTITION BY P.PatientID ORDER BY P.PatientID, P.PatientKey) AS RowNbr
		FROM #Patients P
		)
	SELECT *
	FROM cteDups D
	WHERE D.RowNbr > 1;

	-- Delete duplicate data
	WITH cteDups AS (
		SELECT ROW_NUMBER() OVER(PARTITION BY P.PatientID ORDER BY P.PatientID, P.PatientKey) AS RowNbr
		FROM #Patients P
		)
	DELETE
	FROM cteDups
	WHERE RowNbr > 1;

	-- Show unique data
	SELECT * FROM #Patients ORDER BY PatientID;
	GO

--	Break strings into multiple segments of a given length or less
	DECLARE @len SMALLINT = 100;

	WITH cteStringValues(StringId, StringValue) AS (
		SELECT StringId, StringValue
		FROM (VALUES (1,'Three Irishmen, Paddy, Sean and Seamus, were stumbling home from the pub late one night and found themselves on the road which led past the old graveyard. "Come have a look over here," says Paddy, "It''s Michael O''Grady''s grave, God bless his soul. He lived to the ripe old age of 87."'),
					 (2,'"That''s nothing," says Sean, "here''s one named Patrick O''Toole, it says here that he was 95 when he died."'),
					 (3,'Just then, Seamus yells out, "Good God, here''s a fella that got to be 145!"'),
					 (4,'"What was his name?" asks Paddy.'),
					 (5,'Seamus stumbles around a bit, awkwardly lights a match to see what else is written on the stone marker, and exclaims, "Miles, from Dublin."')) as x(StringId,StringValue)
		)
	SELECT StringId, n AS SeqNbr, substring(StringValue, ((n-1)*@len)+1, @len) AS StringFragment
	FROM cteStringValues AS s
	CROSS APPLY (VALUES (1),(2),(3),(4),(5),(6),(7),(8),(9),(10)) AS t(n) --dbo.fnTally(10) t
	WHERE LEN(StringValue) - ((n-1)*@len) > 0
	ORDER BY StringId, n;

-- Find out how many people have a birthday in each month but don't skip any months

	-- Normally query
	WITH cteBirthday(PatientID, DOB_Month) AS (
		SELECT PatientID, DATEPART(mm, DOB)
		FROM #Patients
		)
	SELECT b.DOB_Month as 'Month', COUNT(*)
	FROM cteBirthday b
	GROUP BY b.DOB_Month;

	-- However, this will not return a row for any month that did not have a birthday.  Instead, use a
	-- tally to ensure that you have totals for all 12 months, even for months without a birthday.

	WITH cteBirthday(PatientID, DOB_Month) AS (
		SELECT PatientID, DATEPART(mm, DOB)
		FROM #Patients
		)
	SELECT t.N as 'Month', COUNT(DOB_Month)
	FROM (VALUES (1),(2),(3),(4),(5),(6),(7),(8),(9),(10),(11),(12)) AS t(n) --dbo.fnTally(12) t
		LEFT JOIN cteBirthday b on t.N = b.DOB_Month
	WHERE t.N <= 12
	GROUP BY t.N;

--
-- Generate a Fibonacci sequence: F(n) = F(n-1) + F(n-2)
--
	DECLARE @n INT = 10;
	WITH cteFibonacci (n, Fibonacci, NextNbr) AS (
		-- Base member definition
		SELECT	1, 0, 1
		UNION ALL
		-- Recursive member definition
		SELECT	n+1, NextNbr, Fibonacci + NextNbr
		FROM	cteFibonacci
		WHERE	n < @n
		)
	-- Statement that executes the CTE
	SELECT	n, Fibonacci
	FROM	cteFibonacci;

--
-- End Demo 3
--